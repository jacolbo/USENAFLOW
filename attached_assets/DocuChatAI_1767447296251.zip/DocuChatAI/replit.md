# ShootTracker - Photoshoot Delivery Management

## Overview
ShootTracker is a production-ready web application that connects to Google Calendar to track photoshoot projects, manage delivery deadlines, and forecast workload. It's designed for photography businesses to monitor job completion and ensure timely delivery.

## Key Features
- **Google Calendar Integration**: OAuth-authenticated access to private calendars
- **Multi-Calendar Aggregation**: Track projects across multiple Google Calendars simultaneously
- **Smart Event Classification**: Automatically categorizes events as Done, Upcoming, or Excluded
- **Delivery Tracking**: Calculate due dates based on configurable working days turnaround
- **Deadline Forecasting**: Visual heatmap and feasibility analysis for meeting deadlines
- **KPI Dashboard**: Real-time metrics for total projects, overdue items, and at-risk deliveries
- **CSV Export**: Download filtered project data for external analysis

## Tech Stack
- **Frontend**: React, Tailwind CSS, Shadcn UI, Recharts
- **Backend**: Express.js, TypeScript
- **Database**: PostgreSQL (Neon) with Drizzle ORM
- **Calendar**: Google Calendar API via Replit Connector
- **Timezone**: Africa/Johannesburg

## Project Structure
```
client/
├── src/
│   ├── components/
│   │   ├── calendar-heatmap.tsx    # Delivery density visualization
│   │   ├── data-table.tsx          # Sortable projects table
│   │   ├── filter-panel.tsx        # Date/deadline/status filters
│   │   ├── kpi-cards.tsx           # Dashboard metrics cards
│   │   ├── navigation-bar.tsx      # Top navigation with calendar selector
│   │   ├── settings-dialog.tsx     # Configuration modal
│   │   └── theme-toggle.tsx        # Dark/light mode switch
│   └── pages/
│       └── dashboard.tsx           # Main dashboard page
server/
├── business-logic.ts               # Event classification, working days, forecasting
├── db.ts                           # Database connection
├── google-calendar.ts              # Google Calendar API integration
├── routes.ts                       # API endpoints
└── storage.ts                      # Database operations
shared/
└── schema.ts                       # Database models and TypeScript types
```

## Business Logic

### Event Classification
- **DONE**: Event end time is in the past, not cancelled/blocked
- **UPCOMING**: Event start time is in the future, not cancelled/blocked
- **EXCLUDED**: Title contains block keywords (FULL DAY, BLOCK, HOLD) or cancel keywords (CANCEL, NO SHOW, etc.)

### Delivery Due Date
Calculated by adding configurable turnaround days (default 5) to shoot date, counting only working days (Mon-Fri by default) and excluding holidays.

### Overdue Detection
An event is overdue if:
- Current date > delivery due date
- Not manually marked as delivered (the "Done" toggle)

Note: Overdue status is determined solely by due date and manual delivery marking, NOT by automatic event classification. This means all past projects will show as overdue until you manually mark them as delivered.

## Authentication
- Session-based authentication with bcrypt password hashing
- All API routes protected with `requireAuth` middleware (return 401 if unauthenticated)
- Session regeneration on login to prevent session fixation
- Required `SESSION_SECRET` environment variable (no fallback)
- Session stored in PostgreSQL via connect-pg-simple

## API Endpoints
All endpoints below require authentication (return 401 if not logged in):
- `GET /api/calendars` - List connected calendars
- `GET /api/settings` - Get user settings
- `PATCH /api/settings` - Update settings
- `GET /api/events` - Fetch and classify events
- `GET /api/kpi` - Calculate dashboard metrics
- `GET /api/forecast` - Generate deadline forecast
- `POST /api/overrides` - Save delivery status/notes

Auth endpoints (no authentication required):
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout
- `GET /api/auth/session` - Check session status

## User Preferences
The user can configure:
- Turnaround time (default: 5 working days)
- Working days (default: Mon-Fri)
- Holidays list
- Block keywords for exclusion
- Cancel/no-show keywords
- Daily editing capacity for feasibility analysis

## Recent Changes
- Added Historical Analytics Dashboard with accurate delivery metrics
  - Uses `deliveredAt` timestamp to calculate on-time delivery rates
  - Turnaround time measured from shoot date to actual delivery date
  - Monthly breakdown with completion rates and performance trends
- Multi-calendar aggregation with bulk operations support
- Lenient date parsing for bulk operations to handle Google Calendar's varied timestamp formats
- PostgreSQL database for persistent settings and delivery overrides
- Comprehensive dashboard with KPI cards, filters, data table, and heatmap
