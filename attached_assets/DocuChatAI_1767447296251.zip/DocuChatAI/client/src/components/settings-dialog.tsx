import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { UserSettings } from "@shared/schema";
import { useState, useEffect } from "react";
import { Loader2 } from "lucide-react";

interface SettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  settings: UserSettings | null;
  onSave: (settings: Partial<UserSettings>) => void;
  isSaving: boolean;
}

const WEEKDAYS = [
  { id: 1, label: "Mon" },
  { id: 2, label: "Tue" },
  { id: 3, label: "Wed" },
  { id: 4, label: "Thu" },
  { id: 5, label: "Fri" },
  { id: 6, label: "Sat" },
  { id: 0, label: "Sun" },
];

export function SettingsDialog({
  open,
  onOpenChange,
  settings,
  onSave,
  isSaving,
}: SettingsDialogProps) {
  const [turnaroundDays, setTurnaroundDays] = useState(5);
  const [workdays, setWorkdays] = useState<number[]>([1, 2, 3, 4, 5]);
  const [holidays, setHolidays] = useState("");
  const [exclusionKeywords, setExclusionKeywords] = useState(
    "FULL DAY,BLOCK,HOLD,OUT OF OFFICE"
  );
  const [cancelKeywords, setCancelKeywords] = useState(
    "CANCEL,CANCELLED,DID NOT COME,NO SHOW,NOT COMING"
  );
  const [capacityPerDay, setCapacityPerDay] = useState<number | null>(null);

  useEffect(() => {
    if (settings) {
      setTurnaroundDays(settings.turnaroundDays);
      setWorkdays(
        settings.workdays
          ? settings.workdays.split(",").map((d) => parseInt(d.trim()))
          : [1, 2, 3, 4, 5]
      );
      setHolidays(settings.holidays || "");
      setExclusionKeywords(
        settings.exclusionKeywords || "FULL DAY,BLOCK,HOLD,OUT OF OFFICE"
      );
      setCancelKeywords(
        settings.cancelKeywords ||
          "CANCEL,CANCELLED,DID NOT COME,NO SHOW,NOT COMING"
      );
      setCapacityPerDay(settings.capacityPerDay);
    }
  }, [settings]);

  const handleSave = () => {
    onSave({
      turnaroundDays,
      workdays: workdays.join(","),
      holidays,
      exclusionKeywords,
      cancelKeywords,
      capacityPerDay,
    });
  };

  const toggleWorkday = (dayId: number) => {
    setWorkdays((prev) =>
      prev.includes(dayId)
        ? prev.filter((d) => d !== dayId)
        : [...prev, dayId].sort()
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Settings</DialogTitle>
          <DialogDescription>
            Configure your delivery tracking preferences.
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="general" className="mt-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="general" data-testid="tab-general">
              General
            </TabsTrigger>
            <TabsTrigger value="workdays" data-testid="tab-workdays">
              Working Days
            </TabsTrigger>
            <TabsTrigger value="exclusions" data-testid="tab-exclusions">
              Exclusions
            </TabsTrigger>
          </TabsList>

          <TabsContent value="general" className="space-y-6 pt-4">
            <div className="space-y-2">
              <Label htmlFor="turnaround">Default Turnaround Time (days)</Label>
              <Input
                id="turnaround"
                type="number"
                min={1}
                max={30}
                value={turnaroundDays}
                onChange={(e) =>
                  setTurnaroundDays(parseInt(e.target.value) || 5)
                }
                className="w-32"
                data-testid="input-settings-turnaround"
              />
              <p className="text-xs text-muted-foreground">
                Number of working days from shoot date to delivery deadline.
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="capacity">Daily Capacity (optional)</Label>
              <Input
                id="capacity"
                type="number"
                min={1}
                max={50}
                value={capacityPerDay ?? ""}
                onChange={(e) =>
                  setCapacityPerDay(
                    e.target.value ? parseInt(e.target.value) : null
                  )
                }
                placeholder="Projects per day"
                className="w-40"
                data-testid="input-settings-capacity"
              />
              <p className="text-xs text-muted-foreground">
                Your editing capacity for feasibility analysis.
              </p>
            </div>
          </TabsContent>

          <TabsContent value="workdays" className="space-y-6 pt-4">
            <div className="space-y-3">
              <Label>Working Days</Label>
              <div className="flex flex-wrap gap-3">
                {WEEKDAYS.map((day) => (
                  <label
                    key={day.id}
                    className="flex cursor-pointer items-center gap-2 rounded-md border px-3 py-2 transition-colors hover:bg-muted"
                  >
                    <Checkbox
                      checked={workdays.includes(day.id)}
                      onCheckedChange={() => toggleWorkday(day.id)}
                      data-testid={`checkbox-workday-${day.id}`}
                    />
                    <span className="text-sm font-medium">{day.label}</span>
                  </label>
                ))}
              </div>
              <p className="text-xs text-muted-foreground">
                Select which days count as working days for delivery
                calculations.
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="holidays">Holidays (one per line)</Label>
              <Textarea
                id="holidays"
                value={holidays}
                onChange={(e) => setHolidays(e.target.value)}
                placeholder="2024-12-25&#10;2024-12-26&#10;2025-01-01"
                rows={5}
                className="font-mono text-sm"
                data-testid="textarea-holidays"
              />
              <p className="text-xs text-muted-foreground">
                Enter dates in YYYY-MM-DD format. These will be excluded from
                working day calculations.
              </p>
            </div>
          </TabsContent>

          <TabsContent value="exclusions" className="space-y-6 pt-4">
            <div className="space-y-2">
              <Label htmlFor="exclusions">Block Keywords (comma-separated)</Label>
              <Textarea
                id="exclusions"
                value={exclusionKeywords}
                onChange={(e) => setExclusionKeywords(e.target.value)}
                placeholder="FULL DAY,BLOCK,HOLD"
                rows={3}
                data-testid="textarea-exclusion-keywords"
              />
              <p className="text-xs text-muted-foreground">
                Events with these keywords in the title will be completely
                ignored.
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="cancel">
                Cancel/No-Show Keywords (comma-separated)
              </Label>
              <Textarea
                id="cancel"
                value={cancelKeywords}
                onChange={(e) => setCancelKeywords(e.target.value)}
                placeholder="CANCEL,CANCELLED,NO SHOW"
                rows={3}
                data-testid="textarea-cancel-keywords"
              />
              <p className="text-xs text-muted-foreground">
                Events with these keywords will be marked as excluded
                (cancelled).
              </p>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter className="mt-6">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            data-testid="button-settings-cancel"
          >
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            disabled={isSaving}
            data-testid="button-settings-save"
          >
            {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Save Changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
