import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import { CalendarEvent } from "@shared/schema";
import { format, parseISO } from "date-fns";
import { cn } from "@/lib/utils";
import {
  CheckCircle,
  Clock,
  AlertTriangle,
  ArrowUpDown,
  FileText,
  CheckSquare,
  X,
  Edit3,
  Link2,
  Search,
} from "lucide-react";
import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";

type QuickFilter = "none" | "linkNotSent" | "notDelivered";

interface DataTableProps {
  events: CalendarEvent[];
  isLoading: boolean;
  onLinkSentToggle: (eventId: string, startTime: string, linkSent: boolean) => void;
  onDeliveryToggle: (eventId: string, startTime: string, delivered: boolean) => void;
  onNotesChange: (eventId: string, startTime: string, notes: string) => void;
  onBulkAction: (
    events: { eventId: string; eventStartTime: string }[], 
    action: string, 
    notes?: string,
    onSuccess?: () => void
  ) => void;
  isBulkActionPending?: boolean;
  quickFilter: QuickFilter;
  onQuickFilterChange: (filter: QuickFilter) => void;
  pendingLinkCount: number;
  pendingDeliveryCount: number;
}

type SortField = "title" | "startTime" | "status" | "deliveryDueDate";
type SortDirection = "asc" | "desc";

function TableRowSkeleton() {
  return (
    <TableRow>
      <TableCell>
        <Skeleton className="h-4 w-4" />
      </TableCell>
      <TableCell>
        <Skeleton className="h-4 w-40" />
      </TableCell>
      <TableCell>
        <Skeleton className="h-4 w-28" />
      </TableCell>
      <TableCell>
        <Skeleton className="h-6 w-20 rounded-full" />
      </TableCell>
      <TableCell>
        <Skeleton className="h-4 w-28" />
      </TableCell>
      <TableCell>
        <Skeleton className="h-5 w-10" />
      </TableCell>
      <TableCell>
        <Skeleton className="h-5 w-10" />
      </TableCell>
      <TableCell>
        <Skeleton className="h-8 w-32" />
      </TableCell>
    </TableRow>
  );
}

function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center" data-testid="empty-state-projects">
      <div className="mb-4 rounded-full bg-muted p-4">
        <FileText className="h-8 w-8 text-muted-foreground" />
      </div>
      <h3 className="text-lg font-medium" data-testid="text-empty-title">No events found</h3>
      <p className="mt-1 max-w-sm text-sm text-muted-foreground" data-testid="text-empty-description">
        Connect a Google Calendar and select a date range to see your photoshoot
        projects.
      </p>
    </div>
  );
}

export function DataTable({
  events,
  isLoading,
  onLinkSentToggle,
  onDeliveryToggle,
  onNotesChange,
  onBulkAction,
  isBulkActionPending = false,
  quickFilter,
  onQuickFilterChange,
  pendingLinkCount,
  pendingDeliveryCount,
}: DataTableProps) {
  const [sortField, setSortField] = useState<SortField>("startTime");
  const [sortDirection, setSortDirection] = useState<SortDirection>("desc");
  const [searchQuery, setSearchQuery] = useState("");
  const [editingNotes, setEditingNotes] = useState<{
    eventId: string;
    startTime: string;
    value: string;
  } | null>(null);
  const [selectedEvents, setSelectedEvents] = useState<Set<string>>(new Set());
  const [bulkNotesDialogOpen, setBulkNotesDialogOpen] = useState(false);
  const [bulkNotesValue, setBulkNotesValue] = useState("");

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection((prev) => (prev === "asc" ? "desc" : "asc"));
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  const filteredAndSortedEvents = useMemo(() => {
    const query = searchQuery.toLowerCase().trim();
    const filtered = query
      ? events.filter((event) => event.title.toLowerCase().includes(query))
      : events;

    return [...filtered].sort((a, b) => {
      let comparison = 0;
      switch (sortField) {
        case "title":
          comparison = a.title.localeCompare(b.title);
          break;
        case "startTime":
          comparison = new Date(a.startTime).getTime() - new Date(b.startTime).getTime();
          break;
        case "status":
          comparison = a.status.localeCompare(b.status);
          break;
        case "deliveryDueDate":
          if (!a.deliveryDueDate && !b.deliveryDueDate) comparison = 0;
          else if (!a.deliveryDueDate) comparison = 1;
          else if (!b.deliveryDueDate) comparison = -1;
          else
            comparison =
              new Date(a.deliveryDueDate).getTime() -
              new Date(b.deliveryDueDate).getTime();
          break;
      }
      return sortDirection === "asc" ? comparison : -comparison;
    });
  }, [events, sortField, sortDirection, searchQuery]);

  const getEventKey = (event: CalendarEvent) => `${event.id}|${event.startTime}`;

  const toggleEventSelection = (event: CalendarEvent) => {
    const key = getEventKey(event);
    setSelectedEvents((prev) => {
      const next = new Set(prev);
      if (next.has(key)) {
        next.delete(key);
      } else {
        next.add(key);
      }
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selectedEvents.size === events.length) {
      setSelectedEvents(new Set());
    } else {
      setSelectedEvents(new Set(events.map(getEventKey)));
    }
  };

  const clearSelection = () => {
    setSelectedEvents(new Set());
  };

  const getSelectedEventData = () => {
    return events
      .filter((e) => selectedEvents.has(getEventKey(e)))
      .map((e) => ({ eventId: e.id, eventStartTime: e.startTime }));
  };

  const handleBulkMarkLinkSent = () => {
    onBulkAction(getSelectedEventData(), "markLinkSent", undefined, clearSelection);
  };

  const handleBulkMarkLinkNotSent = () => {
    onBulkAction(getSelectedEventData(), "markLinkNotSent", undefined, clearSelection);
  };

  const handleBulkMarkDelivered = () => {
    onBulkAction(getSelectedEventData(), "markDelivered", undefined, clearSelection);
  };

  const handleBulkMarkNotDelivered = () => {
    onBulkAction(getSelectedEventData(), "markNotDelivered", undefined, clearSelection);
  };

  const handleBulkSetNotes = () => {
    onBulkAction(getSelectedEventData(), "setNotes", bulkNotesValue, clearSelection);
    setBulkNotesDialogOpen(false);
    setBulkNotesValue("");
  };

  const selectedDoneEvents = events.filter(
    (e) => selectedEvents.has(getEventKey(e)) && e.status === "done"
  );

  const getStatusBadge = (event: CalendarEvent) => {
    if (event.status === "done") {
      if (event.isOverdue && !event.isDelivered) {
        return (
          <Badge
            variant="destructive"
            className="flex items-center gap-1"
            data-testid={`status-overdue-${event.id}`}
          >
            <AlertTriangle className="h-3 w-3" />
            Overdue
          </Badge>
        );
      }
      return (
        <Badge
          className="flex items-center gap-1 bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400"
          data-testid={`status-done-${event.id}`}
        >
          <CheckCircle className="h-3 w-3" />
          Done
        </Badge>
      );
    }
    return (
      <Badge
        className="flex items-center gap-1 bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400"
        data-testid={`status-upcoming-${event.id}`}
      >
        <Clock className="h-3 w-3" />
        Upcoming
      </Badge>
    );
  };

  const SortButton = ({
    field,
    children,
  }: {
    field: SortField;
    children: React.ReactNode;
  }) => (
    <Button
      variant="ghost"
      size="sm"
      className="-ml-3 h-8 data-[state=open]:bg-accent"
      onClick={() => toggleSort(field)}
      data-testid={`sort-${field}`}
    >
      {children}
      <ArrowUpDown
        className={cn(
          "ml-2 h-3.5 w-3.5",
          sortField === field ? "text-foreground" : "text-muted-foreground"
        )}
      />
    </Button>
  );

  return (
    <>
    <Card>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-4 flex-wrap">
            <CardTitle className="flex items-center gap-2 text-xl">
              <FileText className="h-5 w-5" />
              Projects
              {!isLoading && (
                <Badge variant="secondary" className="ml-2 font-mono">
                  {searchQuery ? `${filteredAndSortedEvents.length} / ${events.length}` : events.length}
                </Badge>
              )}
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant={quickFilter === "linkNotSent" ? "default" : "outline"}
                onClick={() => onQuickFilterChange(quickFilter === "linkNotSent" ? "none" : "linkNotSent")}
                className="flex items-center gap-1.5"
                data-testid="button-filter-link-not-sent"
              >
                <Link2 className="h-3.5 w-3.5" />
                Link Not Sent
                <Badge 
                  variant={quickFilter === "linkNotSent" ? "secondary" : "outline"} 
                  className="ml-1 font-mono text-xs"
                >
                  {pendingLinkCount}
                </Badge>
              </Button>
              <Button
                size="sm"
                variant={quickFilter === "notDelivered" ? "default" : "outline"}
                onClick={() => onQuickFilterChange(quickFilter === "notDelivered" ? "none" : "notDelivered")}
                className="flex items-center gap-1.5"
                data-testid="button-filter-not-delivered"
              >
                <AlertTriangle className="h-3.5 w-3.5" />
                Not Delivered
                <Badge 
                  variant={quickFilter === "notDelivered" ? "secondary" : "outline"} 
                  className="ml-1 font-mono text-xs"
                >
                  {pendingDeliveryCount}
                </Badge>
              </Button>
              {quickFilter !== "none" && (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => onQuickFilterChange("none")}
                  data-testid="button-clear-quick-filter"
                >
                  <X className="h-3.5 w-3.5" />
                  Clear
                </Button>
              )}
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search projects..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-64 pl-9"
                data-testid="input-search-projects"
              />
              {searchQuery && (
                <Button
                  size="icon"
                  variant="ghost"
                  className="absolute right-1 top-1/2 h-6 w-6 -translate-y-1/2"
                  onClick={() => setSearchQuery("")}
                  data-testid="button-clear-search"
                >
                  <X className="h-3.5 w-3.5" />
                </Button>
              )}
            </div>
          </div>
          {selectedEvents.size > 0 && (
            <div className="flex items-center gap-2 rounded-md border bg-muted/50 px-3 py-2" data-testid="bulk-action-toolbar">
              <Badge variant="outline" className="font-mono" data-testid="text-selected-count">
                {selectedEvents.size} selected
              </Badge>
              {selectedDoneEvents.length > 0 && (
                <>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleBulkMarkLinkSent}
                    disabled={isBulkActionPending}
                    data-testid="button-bulk-mark-link-sent"
                  >
                    <Link2 className="mr-1 h-3.5 w-3.5" />
                    Link Sent
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleBulkMarkLinkNotSent}
                    disabled={isBulkActionPending}
                    data-testid="button-bulk-mark-link-not-sent"
                  >
                    <X className="mr-1 h-3.5 w-3.5" />
                    Link Not Sent
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleBulkMarkDelivered}
                    disabled={isBulkActionPending}
                    data-testid="button-bulk-mark-delivered"
                  >
                    <CheckSquare className="mr-1 h-3.5 w-3.5" />
                    Delivered
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleBulkMarkNotDelivered}
                    disabled={isBulkActionPending}
                    data-testid="button-bulk-mark-not-delivered"
                  >
                    <X className="mr-1 h-3.5 w-3.5" />
                    Not Delivered
                  </Button>
                </>
              )}
              <Button
                size="sm"
                variant="outline"
                onClick={() => setBulkNotesDialogOpen(true)}
                disabled={isBulkActionPending}
                data-testid="button-bulk-set-notes"
              >
                <Edit3 className="mr-1 h-3.5 w-3.5" />
                Set Notes
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={clearSelection}
                data-testid="button-clear-selection"
              >
                Clear
              </Button>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50px]"></TableHead>
                  <TableHead className="w-[200px]">Client / Title</TableHead>
                  <TableHead className="w-[140px]">Shoot Date</TableHead>
                  <TableHead className="w-[120px]">Status</TableHead>
                  <TableHead className="w-[140px]">Delivery Due</TableHead>
                  <TableHead className="w-[80px]">Link Sent</TableHead>
                  <TableHead className="w-[80px]">Delivered</TableHead>
                  <TableHead className="w-[180px]">Notes</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {[...Array(5)].map((_, i) => (
                  <TableRowSkeleton key={i} />
                ))}
              </TableBody>
            </Table>
          </div>
        ) : events.length === 0 ? (
          <EmptyState />
        ) : (
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead className="w-[50px]">
                    <Checkbox
                      checked={selectedEvents.size === events.length && events.length > 0}
                      onCheckedChange={toggleSelectAll}
                      data-testid="checkbox-select-all"
                    />
                  </TableHead>
                  <TableHead className="w-[200px]">
                    <SortButton field="title">Client / Title</SortButton>
                  </TableHead>
                  <TableHead className="w-[140px]">
                    <SortButton field="startTime">Shoot Date</SortButton>
                  </TableHead>
                  <TableHead className="w-[120px]">
                    <SortButton field="status">Status</SortButton>
                  </TableHead>
                  <TableHead className="w-[140px]">
                    <SortButton field="deliveryDueDate">Delivery Due</SortButton>
                  </TableHead>
                  <TableHead className="w-[80px]">Link Sent</TableHead>
                  <TableHead className="w-[80px]">Delivered</TableHead>
                  <TableHead className="w-[180px]">Notes</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAndSortedEvents.map((event, index) => (
                  <TableRow
                    key={`${event.id}-${event.startTime}`}
                    className={cn(
                      "hover-elevate transition-colors",
                      index % 2 === 0 && "bg-muted/20",
                      selectedEvents.has(getEventKey(event)) && "bg-accent/50"
                    )}
                    data-testid={`row-event-${event.id}`}
                  >
                    <TableCell>
                      <Checkbox
                        checked={selectedEvents.has(getEventKey(event))}
                        onCheckedChange={() => toggleEventSelection(event)}
                        data-testid={`checkbox-event-${event.id}`}
                      />
                    </TableCell>
                    <TableCell className="font-medium">
                      <span
                        className="line-clamp-2"
                        data-testid={`text-title-${event.id}`}
                      >
                        {event.title}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span
                          className="font-mono text-sm"
                          data-testid={`text-date-${event.id}`}
                        >
                          {format(parseISO(event.startTime), "dd MMM yyyy")}
                        </span>
                        <span className="font-mono text-xs text-muted-foreground">
                          {format(parseISO(event.startTime), "HH:mm")}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>{getStatusBadge(event)}</TableCell>
                    <TableCell>
                      {event.deliveryDueDate ? (
                        <span
                          className={cn(
                            "font-mono text-sm",
                            event.isOverdue &&
                              !event.isDelivered &&
                              "font-medium text-red-600 dark:text-red-400"
                          )}
                          data-testid={`text-due-${event.id}`}
                        >
                          {format(parseISO(event.deliveryDueDate), "dd MMM yyyy")}
                        </span>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell>
                      {event.status === "done" && (
                        <Switch
                          checked={event.isLinkSent}
                          onCheckedChange={(checked) =>
                            onLinkSentToggle(event.id, event.startTime, checked)
                          }
                          data-testid={`switch-link-sent-${event.id}`}
                        />
                      )}
                    </TableCell>
                    <TableCell>
                      {event.status === "done" && (
                        <Switch
                          checked={event.isDelivered}
                          onCheckedChange={(checked) =>
                            onDeliveryToggle(event.id, event.startTime, checked)
                          }
                          data-testid={`switch-delivered-${event.id}`}
                        />
                      )}
                    </TableCell>
                    <TableCell>
                      {editingNotes?.eventId === event.id &&
                      editingNotes?.startTime === event.startTime ? (
                        <Input
                          value={editingNotes.value}
                          onChange={(e) =>
                            setEditingNotes({
                              ...editingNotes,
                              value: e.target.value,
                            })
                          }
                          onBlur={() => {
                            onNotesChange(
                              event.id,
                              event.startTime,
                              editingNotes.value
                            );
                            setEditingNotes(null);
                          }}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              onNotesChange(
                                event.id,
                                event.startTime,
                                editingNotes.value
                              );
                              setEditingNotes(null);
                            }
                            if (e.key === "Escape") {
                              setEditingNotes(null);
                            }
                          }}
                          className="h-8"
                          autoFocus
                          data-testid={`input-notes-${event.id}`}
                        />
                      ) : (
                        <button
                          onClick={() =>
                            setEditingNotes({
                              eventId: event.id,
                              startTime: event.startTime,
                              value: event.notes,
                            })
                          }
                          className={cn(
                            "w-full rounded px-2 py-1 text-left text-sm transition-colors hover:bg-muted",
                            !event.notes && "text-muted-foreground"
                          )}
                          data-testid={`button-notes-${event.id}`}
                        >
                          {event.notes || "Add notes..."}
                        </button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>

    <Dialog open={bulkNotesDialogOpen} onOpenChange={setBulkNotesDialogOpen}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Set Notes for {selectedEvents.size} Events</DialogTitle>
          <DialogDescription>
            Enter the notes to apply to all selected events. This will replace any existing notes.
          </DialogDescription>
        </DialogHeader>
        <Textarea
          value={bulkNotesValue}
          onChange={(e) => setBulkNotesValue(e.target.value)}
          placeholder="Enter notes..."
          className="min-h-[100px]"
          data-testid="input-bulk-notes"
        />
        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => {
              setBulkNotesDialogOpen(false);
              setBulkNotesValue("");
            }}
            data-testid="button-cancel-bulk-notes"
          >
            Cancel
          </Button>
          <Button
            onClick={handleBulkSetNotes}
            disabled={isBulkActionPending}
            data-testid="button-confirm-bulk-notes"
          >
            Apply Notes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
    </>
  );
}
