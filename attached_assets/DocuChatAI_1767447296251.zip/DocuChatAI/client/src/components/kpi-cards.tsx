import { Card, CardContent } from "@/components/ui/card";
import { KPIData } from "@shared/schema";
import {
  CheckCircle,
  Clock,
  Calendar,
  AlertTriangle,
  Target,
  TrendingUp,
  FileText,
  PackageCheck,
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

interface KPICardsProps {
  data: KPIData | null;
  isLoading: boolean;
}

interface KPICardConfig {
  key: keyof KPIData;
  label: string;
  icon: typeof CheckCircle;
  colorClass: string;
  iconBgClass: string;
}

const kpiConfig: KPICardConfig[] = [
  {
    key: "total",
    label: "Total Projects",
    icon: FileText,
    colorClass: "text-foreground",
    iconBgClass: "bg-muted",
  },
  {
    key: "done",
    label: "Shoots Done",
    icon: CheckCircle,
    colorClass: "text-emerald-600 dark:text-emerald-400",
    iconBgClass: "bg-emerald-100 dark:bg-emerald-900/30",
  },
  {
    key: "delivered",
    label: "Delivered",
    icon: PackageCheck,
    colorClass: "text-teal-600 dark:text-teal-400",
    iconBgClass: "bg-teal-100 dark:bg-teal-900/30",
  },
  {
    key: "upcoming",
    label: "Upcoming",
    icon: Clock,
    colorClass: "text-blue-600 dark:text-blue-400",
    iconBgClass: "bg-blue-100 dark:bg-blue-900/30",
  },
  {
    key: "dueThisWeek",
    label: "Due This Week",
    icon: Calendar,
    colorClass: "text-amber-600 dark:text-amber-400",
    iconBgClass: "bg-amber-100 dark:bg-amber-900/30",
  },
  {
    key: "overdue",
    label: "Overdue",
    icon: AlertTriangle,
    colorClass: "text-red-600 dark:text-red-400",
    iconBgClass: "bg-red-100 dark:bg-red-900/30",
  },
  {
    key: "dueByDeadline",
    label: "Due by Deadline",
    icon: Target,
    colorClass: "text-purple-600 dark:text-purple-400",
    iconBgClass: "bg-purple-100 dark:bg-purple-900/30",
  },
  {
    key: "atRisk",
    label: "At Risk",
    icon: TrendingUp,
    colorClass: "text-orange-600 dark:text-orange-400",
    iconBgClass: "bg-orange-100 dark:bg-orange-900/30",
  },
];

function KPICardSkeleton() {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            <Skeleton className="h-3 w-20" />
            <Skeleton className="h-10 w-16" />
          </div>
          <Skeleton className="h-10 w-10 rounded-md" />
        </div>
      </CardContent>
    </Card>
  );
}

export function KPICards({ data, isLoading }: KPICardsProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {kpiConfig.slice(0, 4).map((config) => (
          <KPICardSkeleton key={config.key} />
        ))}
        <div className="col-span-1 sm:col-span-2 lg:col-span-4">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {kpiConfig.slice(4).map((config) => (
              <KPICardSkeleton key={config.key} />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4" data-testid="kpi-cards-grid">
        {kpiConfig.slice(0, 4).map((config) => (
          <Card key={config.key} data-testid={`card-kpi-${config.key}`}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <p className="text-sm font-medium uppercase tracking-wide text-muted-foreground" data-testid={`label-kpi-${config.key}`}>
                    {config.label}
                  </p>
                  <p className={cn("font-mono text-4xl font-bold", config.colorClass)} data-testid={`kpi-${config.key}`}>
                    0
                  </p>
                </div>
                <div className={cn("rounded-md p-2.5", config.iconBgClass)}>
                  <config.icon className={cn("h-5 w-5", config.colorClass)} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
        <div className="col-span-1 sm:col-span-2 lg:col-span-4">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {kpiConfig.slice(4).map((config) => (
              <Card key={config.key} data-testid={`card-kpi-${config.key}`}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between gap-4">
                    <div className="space-y-1">
                      <p className="text-sm font-medium uppercase tracking-wide text-muted-foreground" data-testid={`label-kpi-${config.key}`}>
                        {config.label}
                      </p>
                      <p className={cn("font-mono text-4xl font-bold", config.colorClass)} data-testid={`kpi-${config.key}`}>
                        0
                      </p>
                    </div>
                    <div className={cn("rounded-md p-2.5", config.iconBgClass)}>
                      <config.icon className={cn("h-5 w-5", config.colorClass)} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4" data-testid="kpi-cards-grid">
      {kpiConfig.slice(0, 4).map((config) => (
        <Card key={config.key} className="hover-elevate transition-shadow" data-testid={`card-kpi-${config.key}`}>
          <CardContent className="p-6">
            <div className="flex items-start justify-between gap-4">
              <div className="space-y-1">
                <p className="text-sm font-medium uppercase tracking-wide text-muted-foreground" data-testid={`label-kpi-${config.key}`}>
                  {config.label}
                </p>
                <p
                  className={cn("font-mono text-4xl font-bold", config.colorClass)}
                  data-testid={`kpi-${config.key}`}
                >
                  {data[config.key]}
                </p>
              </div>
              <div className={cn("rounded-md p-2.5", config.iconBgClass)}>
                <config.icon className={cn("h-5 w-5", config.colorClass)} />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
      <div className="col-span-1 sm:col-span-2 lg:col-span-4">
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {kpiConfig.slice(4).map((config) => (
            <Card key={config.key} className="hover-elevate transition-shadow" data-testid={`card-kpi-${config.key}`}>
              <CardContent className="p-6">
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-1">
                    <p className="text-sm font-medium uppercase tracking-wide text-muted-foreground" data-testid={`label-kpi-${config.key}`}>
                      {config.label}
                    </p>
                    <p
                      className={cn("font-mono text-4xl font-bold", config.colorClass)}
                      data-testid={`kpi-${config.key}`}
                    >
                      {data[config.key]}
                    </p>
                  </div>
                  <div className={cn("rounded-md p-2.5", config.iconBgClass)}>
                    <config.icon className={cn("h-5 w-5", config.colorClass)} />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
