import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { CalendarIcon, ChevronDown, Filter, X } from "lucide-react";
import { format, parseISO } from "date-fns";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";

export interface FilterState {
  dateRangeStart: string | null;
  dateRangeEnd: string | null;
  deadlineDate: string | null;
  turnaroundDays: number;
  statusFilter: "all" | "done" | "upcoming";
}

interface FilterPanelProps {
  filters: FilterState;
  onFiltersChange: (filters: FilterState) => void;
  onReset: () => void;
}

export function FilterPanel({
  filters,
  onFiltersChange,
  onReset,
}: FilterPanelProps) {
  const [isAdvancedOpen, setIsAdvancedOpen] = useState(false);

  const updateFilter = <K extends keyof FilterState>(
    key: K,
    value: FilterState[K]
  ) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  const activeFilterCount =
    (filters.dateRangeStart ? 1 : 0) +
    (filters.dateRangeEnd ? 1 : 0) +
    (filters.deadlineDate ? 1 : 0) +
    (filters.turnaroundDays !== 5 ? 1 : 0) +
    (filters.statusFilter !== "all" ? 1 : 0);

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm font-medium" data-testid="text-filter-label">Filters</span>
            {activeFilterCount > 0 && (
              <Badge variant="secondary" className="text-xs" data-testid="badge-active-filter-count">
                {activeFilterCount}
              </Badge>
            )}
          </div>

          <div className="flex flex-1 flex-wrap items-center gap-3">
            <div className="flex items-center gap-2">
              <Label className="text-xs text-muted-foreground whitespace-nowrap">
                From
              </Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-32 justify-start text-left font-normal",
                      !filters.dateRangeStart && "text-muted-foreground"
                    )}
                    data-testid="input-date-from"
                  >
                    <CalendarIcon className="mr-2 h-3.5 w-3.5" />
                    {filters.dateRangeStart
                      ? format(parseISO(filters.dateRangeStart), "dd MMM yy")
                      : "Start"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={
                      filters.dateRangeStart
                        ? parseISO(filters.dateRangeStart)
                        : undefined
                    }
                    onSelect={(date) =>
                      updateFilter(
                        "dateRangeStart",
                        date ? format(date, "yyyy-MM-dd") : null
                      )
                    }
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="flex items-center gap-2">
              <Label className="text-xs text-muted-foreground whitespace-nowrap">
                To
              </Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-32 justify-start text-left font-normal",
                      !filters.dateRangeEnd && "text-muted-foreground"
                    )}
                    data-testid="input-date-to"
                  >
                    <CalendarIcon className="mr-2 h-3.5 w-3.5" />
                    {filters.dateRangeEnd
                      ? format(parseISO(filters.dateRangeEnd), "dd MMM yy")
                      : "End"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={
                      filters.dateRangeEnd
                        ? parseISO(filters.dateRangeEnd)
                        : undefined
                    }
                    onSelect={(date) =>
                      updateFilter(
                        "dateRangeEnd",
                        date ? format(date, "yyyy-MM-dd") : null
                      )
                    }
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="h-6 w-px bg-border" />

            <div className="flex items-center gap-2">
              <Label className="text-xs text-muted-foreground whitespace-nowrap">
                Deadline
              </Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-36 justify-start text-left font-normal",
                      !filters.deadlineDate && "text-muted-foreground"
                    )}
                    data-testid="input-deadline"
                  >
                    <CalendarIcon className="mr-2 h-3.5 w-3.5" />
                    {filters.deadlineDate
                      ? format(parseISO(filters.deadlineDate), "dd MMM yyyy")
                      : "Select"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={
                      filters.deadlineDate
                        ? parseISO(filters.deadlineDate)
                        : undefined
                    }
                    onSelect={(date) =>
                      updateFilter(
                        "deadlineDate",
                        date ? format(date, "yyyy-MM-dd") : null
                      )
                    }
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="flex items-center gap-1.5">
              <Button
                variant={filters.statusFilter === "all" ? "secondary" : "ghost"}
                size="sm"
                onClick={() => updateFilter("statusFilter", "all")}
                data-testid="filter-status-all"
              >
                All
              </Button>
              <Button
                variant={filters.statusFilter === "done" ? "secondary" : "ghost"}
                size="sm"
                onClick={() => updateFilter("statusFilter", "done")}
                data-testid="filter-status-done"
              >
                Done
              </Button>
              <Button
                variant={
                  filters.statusFilter === "upcoming" ? "secondary" : "ghost"
                }
                size="sm"
                onClick={() => updateFilter("statusFilter", "upcoming")}
                data-testid="filter-status-upcoming"
              >
                Upcoming
              </Button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Collapsible open={isAdvancedOpen} onOpenChange={setIsAdvancedOpen}>
              <CollapsibleTrigger asChild>
                <Button variant="ghost" size="sm" data-testid="button-advanced-filters">
                  Advanced
                  <ChevronDown
                    className={cn(
                      "ml-1 h-3.5 w-3.5 transition-transform",
                      isAdvancedOpen && "rotate-180"
                    )}
                  />
                </Button>
              </CollapsibleTrigger>
            </Collapsible>

            {activeFilterCount > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onReset}
                data-testid="button-reset-filters"
              >
                <X className="mr-1 h-3.5 w-3.5" />
                Reset
              </Button>
            )}
          </div>
        </div>

        <Collapsible open={isAdvancedOpen} onOpenChange={setIsAdvancedOpen}>
          <CollapsibleContent>
            <div className="mt-4 flex flex-wrap items-center gap-4 border-t pt-4">
              <div className="flex items-center gap-2">
                <Label
                  htmlFor="turnaround"
                  className="text-xs text-muted-foreground whitespace-nowrap"
                >
                  Turnaround Days
                </Label>
                <Input
                  id="turnaround"
                  type="number"
                  min={1}
                  max={30}
                  value={filters.turnaroundDays}
                  onChange={(e) =>
                    updateFilter("turnaroundDays", parseInt(e.target.value) || 5)
                  }
                  className="w-20"
                  data-testid="input-turnaround"
                />
              </div>
            </div>
          </CollapsibleContent>
        </Collapsible>
      </CardContent>
    </Card>
  );
}
