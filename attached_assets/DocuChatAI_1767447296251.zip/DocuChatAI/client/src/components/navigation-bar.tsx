import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Camera, Download, Settings, ChevronsUpDown, Calendar, BarChart3, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "./theme-toggle";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { CalendarInfo } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface NavigationBarProps {
  calendars: CalendarInfo[];
  selectedCalendarIds: string[];
  onCalendarChange: (calendarIds: string[]) => void;
  onExportCSV: () => void;
  onOpenSettings: () => void;
  onLogout: () => void;
  isLoadingCalendars: boolean;
  isConnected: boolean;
  username?: string;
}

export function NavigationBar({
  calendars,
  selectedCalendarIds,
  onCalendarChange,
  onExportCSV,
  onOpenSettings,
  onLogout,
  isLoadingCalendars,
  isConnected,
  username,
}: NavigationBarProps) {
  const [open, setOpen] = useState(false);

  const safeSelectedIds = selectedCalendarIds || [];

  const toggleCalendar = (calId: string) => {
    if (safeSelectedIds.includes(calId)) {
      onCalendarChange(safeSelectedIds.filter(id => id !== calId));
    } else {
      onCalendarChange([...safeSelectedIds, calId]);
    }
  };

  const selectAll = () => {
    onCalendarChange(calendars.map(c => c.id));
  };

  const clearAll = () => {
    onCalendarChange([]);
  };

  const getDisplayText = () => {
    if (safeSelectedIds.length === 0) return "Select calendars";
    if (safeSelectedIds.length === 1) {
      const cal = calendars.find(c => c.id === safeSelectedIds[0]);
      return cal?.summary || "1 calendar";
    }
    return `${safeSelectedIds.length} calendars`;
  };

  return (
    <header className="sticky top-0 z-50 h-16 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="mx-auto flex h-full max-w-7xl items-center justify-between gap-4 px-6">
        <div className="flex items-center gap-3" data-testid="nav-logo">
          <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary">
            <Camera className="h-5 w-5 text-primary-foreground" />
          </div>
          <div className="flex flex-col">
            <h1 className="text-lg font-semibold tracking-tight" data-testid="text-app-title">ShootTracker</h1>
            <span className="text-xs text-muted-foreground" data-testid="text-app-subtitle">Delivery Management</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {isLoadingCalendars ? (
            <Skeleton className="h-9 w-56" />
          ) : isConnected && calendars.length > 0 ? (
            <Popover open={open} onOpenChange={setOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  aria-expanded={open}
                  className="w-56 justify-between"
                  data-testid="select-calendar"
                >
                  <div className="flex items-center gap-2 truncate">
                    <Calendar className="h-4 w-4 shrink-0 text-muted-foreground" />
                    <span className="truncate">{getDisplayText()}</span>
                  </div>
                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-64 p-0" align="start">
                <div className="border-b p-2">
                  <div className="flex items-center justify-between gap-2">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={selectAll}
                      className="h-7 text-xs"
                      data-testid="button-select-all-calendars"
                    >
                      Select All
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={clearAll}
                      className="h-7 text-xs"
                      data-testid="button-clear-calendars"
                    >
                      Clear
                    </Button>
                  </div>
                </div>
                <div className="max-h-64 overflow-y-auto p-2">
                  {calendars.map((cal) => {
                    const isSelected = safeSelectedIds.includes(cal.id);
                    return (
                      <div
                        key={cal.id}
                        className={cn(
                          "flex cursor-pointer items-center gap-2 rounded-md px-2 py-1.5 text-sm hover-elevate",
                          isSelected && "bg-accent"
                        )}
                        onClick={() => toggleCalendar(cal.id)}
                        data-testid={`calendar-option-${cal.id}`}
                      >
                        <Checkbox
                          checked={isSelected}
                          onCheckedChange={() => toggleCalendar(cal.id)}
                          data-testid={`checkbox-calendar-${cal.id}`}
                        />
                        <span className="flex-1 truncate">{cal.summary}</span>
                        {cal.primary && (
                          <Badge variant="secondary" className="text-xs">Primary</Badge>
                        )}
                      </div>
                    );
                  })}
                </div>
                {safeSelectedIds.length > 0 && (
                  <div className="border-t p-2">
                    <p className="text-xs text-muted-foreground">
                      {safeSelectedIds.length} calendar{safeSelectedIds.length !== 1 ? 's' : ''} selected
                    </p>
                  </div>
                )}
              </PopoverContent>
            </Popover>
          ) : (
            <div className="flex items-center gap-2 rounded-md border border-dashed px-3 py-2 text-sm text-muted-foreground" data-testid="text-calendar-empty-prompt">
              <span>Connect Google Calendar in Settings</span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-1">
          <Link href="/analytics">
            <Button
              size="icon"
              variant="ghost"
              data-testid="button-analytics"
            >
              <BarChart3 className="h-4 w-4" />
            </Button>
          </Link>
          <Button
            size="icon"
            variant="ghost"
            onClick={onExportCSV}
            data-testid="button-export-csv"
          >
            <Download className="h-4 w-4" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            onClick={onOpenSettings}
            data-testid="button-settings"
          >
            <Settings className="h-4 w-4" />
          </Button>
          <ThemeToggle />
          <div className="ml-2 flex items-center gap-2 border-l pl-3">
            {username && (
              <span className="text-sm text-muted-foreground" data-testid="text-username">
                {username}
              </span>
            )}
            <Button
              size="icon"
              variant="ghost"
              onClick={onLogout}
              data-testid="button-logout"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
