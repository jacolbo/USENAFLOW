import { useQuery } from "@tanstack/react-query";
import { useState, useMemo } from "react";
import { format, subMonths, startOfMonth, endOfMonth } from "date-fns";
import { Link } from "wouter";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Legend, Cell, Area, AreaChart, ComposedChart, Tooltip as RechartsTooltip } from "recharts";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, TrendingUp, CheckCircle, Clock, BarChart3, Calendar } from "lucide-react";
import { type AnalyticsData, type CalendarInfo, type UserSettings } from "@shared/schema";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart";

function AnalyticsSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardHeader className="pb-2">
              <Skeleton className="h-4 w-24" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-10 w-20" />
            </CardContent>
          </Card>
        ))}
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-40" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-64 w-full" />
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-40" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-64 w-full" />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function EmptyAnalytics() {
  return (
    <Card data-testid="empty-state-analytics">
      <CardContent className="py-16 text-center">
        <div className="mb-4 inline-flex rounded-full bg-muted p-4">
          <BarChart3 className="h-8 w-8 text-muted-foreground" />
        </div>
        <h3 className="text-lg font-medium" data-testid="text-analytics-empty-title">
          No Analytics Data
        </h3>
        <p className="mt-2 text-sm text-muted-foreground max-w-md mx-auto" data-testid="text-analytics-empty-description">
          Select a calendar and date range to view historical analytics. Analytics are calculated from completed projects.
        </p>
        <Link href="/">
          <Button variant="outline" className="mt-4" data-testid="button-go-to-dashboard">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}

const completionChartConfig: ChartConfig = {
  done: {
    label: "Completed",
    color: "hsl(var(--muted-foreground))",
  },
  delivered: {
    label: "Delivered",
    color: "hsl(var(--primary))",
  },
};

const turnaroundChartConfig: ChartConfig = {
  avgTurnaroundDays: {
    label: "Avg Turnaround",
    color: "hsl(var(--primary))",
  },
};

const onTimeChartConfig: ChartConfig = {
  onTimeDeliveries: {
    label: "On-Time",
    color: "hsl(142.1 76.2% 36.3%)",
  },
  lateDeliveries: {
    label: "Late",
    color: "hsl(var(--destructive))",
  },
};

export default function Analytics() {
  const [selectedCalendarIds, setSelectedCalendarIds] = useState<string[]>([]);
  const [dateRange, setDateRange] = useState<"6m" | "12m" | "24m">("12m");

  const { start, end } = useMemo(() => {
    const now = new Date();
    const months = dateRange === "6m" ? 6 : dateRange === "12m" ? 12 : 24;
    return {
      start: format(startOfMonth(subMonths(now, months)), "yyyy-MM-dd"),
      end: format(endOfMonth(now), "yyyy-MM-dd"),
    };
  }, [dateRange]);

  const { data: calendars } = useQuery<CalendarInfo[]>({
    queryKey: ["/api/calendars"],
  });

  const { data: settings } = useQuery<UserSettings>({
    queryKey: ["/api/settings"],
  });

  useMemo(() => {
    if (settings?.selectedCalendarIds && selectedCalendarIds.length === 0) {
      const ids = settings.selectedCalendarIds.split(",").filter((id) => id.trim());
      if (ids.length > 0) {
        setSelectedCalendarIds(ids);
      }
    }
  }, [settings?.selectedCalendarIds, selectedCalendarIds.length]);

  const calendarIdsParam = selectedCalendarIds.join(",");

  const {
    data: analytics,
    isLoading,
  } = useQuery<AnalyticsData>({
    queryKey: ["/api/analytics", { calendarIds: calendarIdsParam, start, end }],
    enabled: selectedCalendarIds.length > 0,
  });

  const chartData = useMemo(() => {
    if (!analytics?.monthlyStats) return [];
    return analytics.monthlyStats.map((stat) => ({
      ...stat,
      monthLabel: format(new Date(stat.month + "-01"), "MMM yyyy"),
      lateDeliveries: stat.delivered - stat.onTimeDeliveries,
    }));
  }, [analytics?.monthlyStats]);

  const handleCalendarChange = (value: string) => {
    if (value === "all" && calendars) {
      setSelectedCalendarIds(calendars.map((c) => c.id));
    } else {
      setSelectedCalendarIds([value]);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center gap-4 px-6">
          <Link href="/">
            <Button variant="ghost" size="icon" data-testid="button-back-to-dashboard">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div className="flex items-center gap-2">
            <BarChart3 className="h-6 w-6 text-primary" />
            <h1 className="text-xl font-semibold">Analytics</h1>
          </div>
          <div className="ml-auto flex items-center gap-4">
            <Select
              value={selectedCalendarIds.length === calendars?.length && calendars?.length > 1 ? "all" : selectedCalendarIds[0] || ""}
              onValueChange={handleCalendarChange}
            >
              <SelectTrigger className="w-[200px]" data-testid="select-calendar-analytics">
                <SelectValue placeholder="Select calendar" />
              </SelectTrigger>
              <SelectContent>
                {calendars && calendars.length > 1 && (
                  <SelectItem value="all" data-testid="select-calendar-all">
                    All Calendars
                  </SelectItem>
                )}
                {calendars?.map((cal) => (
                  <SelectItem key={cal.id} value={cal.id} data-testid={`select-calendar-${cal.id}`}>
                    {cal.summary}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={dateRange} onValueChange={(v) => setDateRange(v as "6m" | "12m" | "24m")}>
              <SelectTrigger className="w-[140px]" data-testid="select-date-range">
                <Calendar className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="6m" data-testid="select-range-6m">Last 6 months</SelectItem>
                <SelectItem value="12m" data-testid="select-range-12m">Last 12 months</SelectItem>
                <SelectItem value="24m" data-testid="select-range-24m">Last 24 months</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </header>

      <main className="container px-6 py-8">
        {isLoading ? (
          <AnalyticsSkeleton />
        ) : !analytics || analytics.totalProjects === 0 ? (
          <EmptyAnalytics />
        ) : (
          <div className="space-y-8">
            <div className="grid gap-4 md:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
                  <CardTitle className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
                    Total Projects
                  </CardTitle>
                  <BarChart3 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <p className="text-4xl font-bold font-mono" data-testid="stat-total-projects">
                    {analytics.totalProjects}
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
                  <CardTitle className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
                    Completion Rate
                  </CardTitle>
                  <CheckCircle className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <p className="text-4xl font-bold font-mono" data-testid="stat-completion-rate">
                    {analytics.overallCompletionRate.toFixed(1)}%
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    {analytics.deliveredProjects} delivered
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
                  <CardTitle className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
                    On-Time Rate
                  </CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <p
                    className={`text-4xl font-bold font-mono ${
                      analytics.overallOnTimeRate >= 90
                        ? "text-emerald-600 dark:text-emerald-400"
                        : analytics.overallOnTimeRate >= 70
                        ? "text-amber-600 dark:text-amber-400"
                        : "text-red-600 dark:text-red-400"
                    }`}
                    data-testid="stat-on-time-rate"
                  >
                    {analytics.overallOnTimeRate.toFixed(1)}%
                  </p>
                  <Badge
                    variant={analytics.overallOnTimeRate >= 90 ? "default" : analytics.overallOnTimeRate >= 70 ? "secondary" : "destructive"}
                    className="mt-1"
                    data-testid="badge-on-time-status"
                  >
                    {analytics.overallOnTimeRate >= 90 ? "Excellent" : analytics.overallOnTimeRate >= 70 ? "Good" : "Needs Improvement"}
                  </Badge>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
                  <CardTitle className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
                    Avg Turnaround
                  </CardTitle>
                  <Clock className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <p className="text-4xl font-bold font-mono" data-testid="stat-avg-turnaround">
                    {analytics.avgTurnaroundDays}
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    working days
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-6 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-muted-foreground" />
                    Completion Over Time
                  </CardTitle>
                  <CardDescription>
                    Monthly breakdown of completed vs delivered projects
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ChartContainer config={completionChartConfig} className="h-[300px]">
                    <BarChart data={chartData} accessibilityLayer>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis
                        dataKey="monthLabel"
                        tickLine={false}
                        axisLine={false}
                        tickMargin={8}
                      />
                      <YAxis tickLine={false} axisLine={false} tickMargin={8} />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Legend />
                      <Bar
                        dataKey="done"
                        fill="var(--color-done)"
                        radius={[4, 4, 0, 0]}
                        name="Completed"
                      />
                      <Bar
                        dataKey="delivered"
                        fill="var(--color-delivered)"
                        radius={[4, 4, 0, 0]}
                        name="Delivered"
                      />
                    </BarChart>
                  </ChartContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-muted-foreground" />
                    Turnaround Trend
                  </CardTitle>
                  <CardDescription>
                    Average turnaround time in working days by month
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ChartContainer config={turnaroundChartConfig} className="h-[300px]">
                    <LineChart data={chartData} accessibilityLayer>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis
                        dataKey="monthLabel"
                        tickLine={false}
                        axisLine={false}
                        tickMargin={8}
                      />
                      <YAxis tickLine={false} axisLine={false} tickMargin={8} />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Line
                        type="monotone"
                        dataKey="avgTurnaroundDays"
                        stroke="var(--color-avgTurnaroundDays)"
                        strokeWidth={2}
                        dot={{ r: 4 }}
                        activeDot={{ r: 6 }}
                        name="Avg Turnaround (days)"
                      />
                    </LineChart>
                  </ChartContainer>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-muted-foreground" />
                  On-Time Delivery Performance
                </CardTitle>
                <CardDescription>
                  Breakdown of on-time vs late deliveries by month
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ChartContainer config={onTimeChartConfig} className="h-[300px]">
                  <ComposedChart data={chartData} accessibilityLayer>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis
                      dataKey="monthLabel"
                      tickLine={false}
                      axisLine={false}
                      tickMargin={8}
                    />
                    <YAxis tickLine={false} axisLine={false} tickMargin={8} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Legend />
                    <Bar
                      dataKey="onTimeDeliveries"
                      stackId="a"
                      fill="var(--color-onTimeDeliveries)"
                      radius={[0, 0, 0, 0]}
                      name="On-Time"
                    />
                    <Bar
                      dataKey="lateDeliveries"
                      stackId="a"
                      fill="var(--color-lateDeliveries)"
                      radius={[4, 4, 0, 0]}
                      name="Late"
                    />
                  </ComposedChart>
                </ChartContainer>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
}
