# Design Guidelines: Photoshoot Delivery Dashboard

## Design Approach: Data-Focused Dashboard System

**Selected Framework:** Carbon Design System principles adapted for photography workflow management
**Rationale:** This is a data-intensive productivity tool requiring clarity, efficient scanning, and professional presentation of complex information. The design prioritizes information hierarchy and functional efficiency over visual embellishment.

---

## Core Design Elements

### Typography
- **Primary Font:** IBM Plex Sans (via Google Fonts CDN)
- **Monospace:** IBM Plex Mono for dates, numbers, and data values
- **Hierarchy:**
  - Page titles: 2xl, semibold (tracking-tight)
  - Section headers: xl, medium
  - KPI values: 3xl, bold (for dashboard metrics)
  - KPI labels: sm, medium, uppercase tracking
  - Table headers: sm, semibold
  - Table data: base, regular
  - Filter labels: sm, medium

### Layout System
**Spacing Primitives:** Tailwind units of 2, 4, 6, 8, 12, 16
- Component padding: p-6 to p-8
- Card spacing: gap-6 for grids, space-y-6 for stacks
- Section margins: mb-8 to mb-12
- Container max-width: max-w-7xl with px-6

---

## Component Library

### Dashboard Layout
**Primary Structure:**
- Fixed top navigation bar (h-16) with logo, calendar selector, and settings
- Main content area with max-w-7xl container
- Three-tier information architecture:
  1. KPI Cards Grid (top)
  2. Filters & Controls (middle)
  3. Data Table + Calendar Heatmap (bottom)

### KPI Cards
**7-card grid layout:**
- Desktop: grid-cols-4 (first row) + grid-cols-3 (second row)
- Tablet: grid-cols-2
- Mobile: grid-cols-1
- Each card: rounded-lg border, p-6, hover:shadow-md transition
- Structure per card:
  - Label (uppercase, tracking-wide, text-sm)
  - Value (text-4xl, font-bold, mt-2)
  - Trend indicator or subtext (text-sm, mt-1)
- Conditional styling: Green accent for on-track metrics, red for overdue/at-risk

### Filters Panel
**Horizontal filter bar with collapsible advanced options:**
- Primary filters always visible: Date Range picker, Deadline selector, Quick filter chips
- Advanced filters (collapsible): Turnaround days input, Exclusion keywords, Workdays selector
- Filter layout: flex flex-wrap gap-4, items-center
- Each filter: bg-white border rounded-md p-3

### Data Table
**Professional data grid with fixed header:**
- Sticky header with sort indicators
- Alternating row backgrounds (subtle stripe pattern)
- Columns: Client/Title (flexible), Shoot Date (w-40), Status badge (w-32), Delivery Due (w-40), Delivery Toggle (w-36), Notes (w-48)
- Row height: py-3 for comfortable scanning
- Interactive rows: hover:bg-gray-50 transition
- Status badges: Rounded-full pills with appropriate semantic colors
- Delivery toggle: Custom switch component, inline interaction
- Empty state: Centered illustration with helpful message

### Calendar Heatmap
**Working days visualization:**
- Monthly grid layout showing delivery density
- Each day: Square cell with rounded corners, variable opacity based on workload
- Tooltip on hover showing exact count and date
- Legend showing workload intensity scale
- Responsive: Scrollable horizontally on mobile

### Navigation Bar
**Fixed top bar structure:**
- Left: App logo + name ("ShootTracker" or similar)
- Center: Calendar source selector (dropdown with OAuth status indicator)
- Right: Export CSV button, Settings icon, User avatar
- Height: h-16, border-b, backdrop-blur for elevated feel

### Modal/Settings Overlay
**Configuration panel:**
- Full-screen overlay on mobile, centered modal on desktop (max-w-2xl)
- Tabbed interface: Calendar Setup, Working Days, Exclusions, Preferences
- Form sections with clear labels and helper text
- Save/Cancel actions in sticky footer

---

## Visual Hierarchy & Spacing

**Information Density Strategy:**
- KPI cards: Breathing room with p-6, gap-6
- Filters: Compact but touchable (min-h-12 inputs)
- Table: Dense packing with clear row separation
- Calendar: Square cells maintaining aspect ratio

**Vertical Rhythm:**
- Navbar: fixed at top
- Content padding: pt-8 pb-16
- Section spacing: space-y-8 between major blocks
- Card grids: gap-6

---

## Interactive Elements

### Buttons
- Primary action: Solid with semibold text (Export, Save, Apply Filters)
- Secondary: Outline variant (Cancel, Reset)
- Icon buttons: Square with centered icon, hover:bg-gray-100
- Size: px-4 py-2 (base), px-6 py-3 (large)

### Form Controls
- Inputs: border rounded-md px-3 py-2, focus:ring-2
- Dropdowns: Custom select with chevron icon
- Toggles: Smooth sliding switch (w-11 h-6)
- Date pickers: Calendar popup with month navigation

### Status Indicators
- Done: Green badge with checkmark icon
- Upcoming: Blue badge with clock icon
- Overdue: Red badge with alert icon
- Delivered: Success state toggle
- Not Delivered: Default state toggle

---

## Responsive Behavior

**Breakpoint Strategy:**
- Mobile (<768px): Single column, stacked filters, scrollable table
- Tablet (768px-1024px): 2-column KPIs, compact filters
- Desktop (>1024px): Full grid layouts, all features visible

**Mobile Adaptations:**
- Horizontal scroll for table
- Filter panel collapses to dropdown
- KPI cards stack vertically
- Calendar heatmap scrolls horizontally with sticky month labels

---

## Data Visualization

**Calendar Heatmap Specifics:**
- Cell size: 40px × 40px on desktop, 32px × 32px on mobile
- Intensity scale: 0 deliveries (transparent) to 5+ (full saturation)
- Weekend days: Visually dimmed or excluded based on workday settings
- Holiday markers: Diagonal stripe pattern
- Current day: Distinct border treatment

**Forecast Visualization:**
- Required throughput: Large metric with trend arrow
- Capacity gauge: Progress bar showing utilization percentage
- Feasibility indicator: Traffic light system (green/amber/red) with clear messaging

---

## Images

**No hero image needed** - This is a functional dashboard prioritizing data visibility immediately upon load.

**Illustration usage:**
- Empty state: Simple line illustration of calendar with checkmarks (placed in table empty state)
- Error state: Friendly illustration for connection issues
- Onboarding: Optional quick-start visual guide in settings

**Icon library:** Heroicons (via CDN) for consistency
- Use outline variant for inactive states
- Use solid variant for active states and filled buttons

---

## Special Considerations

**Performance Optimizations:**
- Virtualized table scrolling for 100+ entries
- Lazy load calendar heatmap data
- Debounced filter inputs

**Professional Polish:**
- Loading skeletons for data fetching states
- Smooth transitions on sort/filter changes
- Contextual tooltips for complex features
- Inline help text using muted colors

**Accessibility:**
- ARIA labels for all interactive elements
- Keyboard navigation for table rows and filters
- Screen reader announcements for status changes
- Sufficient contrast ratios throughout