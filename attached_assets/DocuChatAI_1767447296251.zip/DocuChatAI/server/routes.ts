import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { listCalendars, getEvents } from "./google-calendar";
import {
  processEvents,
  calculateKPIs,
  calculateForecast,
  calculateAnalytics,
  parseWorkdays,
  parseHolidays,
  parseKeywords,
  type Settings,
} from "./business-logic";
import { z } from "zod";
import bcrypt from "bcrypt";
import "express-session";

const ISO_DATE_REGEX = /^(\d{4})-(\d{2})-(\d{2})$/;
const ISO_DATE_TIME_REGEX = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.(\d{3}))?(Z|([+-])(\d{2}):(\d{2}))$/;

const pad = (value: number, length: number) => value.toString().padStart(length, "0");

type ParseResult<T> = { success: true; value: T } | { success: false; message: string };

function parseStrictIsoDate(value: string): ParseResult<Date> {
  if (value.length === 0 || value !== value.trim()) {
    return { success: false, message: "Whitespace not allowed in date" };
  }
  const match = ISO_DATE_REGEX.exec(value);
  if (!match) {
    return { success: false, message: "Must be YYYY-MM-DD format" };
  }
  const [, yStr, mStr, dStr] = match;
  const year = Number(yStr);
  const month = Number(mStr);
  const day = Number(dStr);
  if (year < 2000 || year > 2100 || month < 1 || month > 12) {
    return { success: false, message: "Date is out of range (2000-2100)" };
  }
  const daysInMonth = new Date(Date.UTC(year, month, 0)).getUTCDate();
  if (day < 1 || day > daysInMonth) {
    return { success: false, message: "Invalid day for month" };
  }
  const canonical = `${pad(year, 4)}-${pad(month, 2)}-${pad(day, 2)}`;
  if (canonical !== value) {
    return { success: false, message: `Date must be canonical (expected ${canonical})` };
  }
  return { success: true, value: new Date(Date.UTC(year, month - 1, day)) };
}

function parseStrictIsoDateTime(value: string): ParseResult<Date> {
  if (value.length === 0 || value !== value.trim()) {
    return { success: false, message: "Whitespace not allowed in date/time" };
  }
  const match = ISO_DATE_TIME_REGEX.exec(value);
  if (!match) {
    return { success: false, message: "Must be ISO-8601 with timezone (e.g., 2025-01-15T10:30:00Z)" };
  }
  const [, yStr, mStr, dStr, hhStr, mmStr, ssStr, millisStr, tzToken, tzSign, tzHoursStr, tzMinutesStr] = match;
  const year = Number(yStr);
  const month = Number(mStr);
  const day = Number(dStr);
  const hour = Number(hhStr);
  const minute = Number(mmStr);
  const second = Number(ssStr);
  const millisecond = millisStr ? Number(millisStr) : 0;
  if (year < 2000 || year > 2100 || month < 1 || month > 12) {
    return { success: false, message: "Date is out of range (2000-2100)" };
  }
  const daysInMonth = new Date(Date.UTC(year, month, 0)).getUTCDate();
  if (day < 1 || day > daysInMonth) {
    return { success: false, message: "Invalid day for month" };
  }
  if (hour > 23 || minute > 59 || second > 59) {
    return { success: false, message: "Invalid time components" };
  }
  let offsetMinutes = 0;
  if (tzToken !== "Z") {
    const tzHours = Number(tzHoursStr);
    const tzMinutes = Number(tzMinutesStr);
    if (tzHours > 14 || tzMinutes > 59) {
      return { success: false, message: "Invalid timezone offset (max ±14:00)" };
    }
    if (tzHours === 14 && tzMinutes !== 0) {
      return { success: false, message: "Timezone offset at ±14 must be whole hours" };
    }
    offsetMinutes = (tzHours * 60 + tzMinutes) * (tzSign === "+" ? 1 : -1);
  }
  const epochMs = Date.UTC(year, month - 1, day, hour, minute, second, millisecond) - offsetMinutes * 60 * 1000;
  const localMs = epochMs + offsetMinutes * 60 * 1000;
  const local = new Date(localMs);
  if (
    local.getUTCFullYear() !== year ||
    local.getUTCMonth() + 1 !== month ||
    local.getUTCDate() !== day ||
    local.getUTCHours() !== hour ||
    local.getUTCMinutes() !== minute ||
    local.getUTCSeconds() !== second ||
    local.getUTCMilliseconds() !== millisecond
  ) {
    return { success: false, message: "Datetime normalization mismatch" };
  }
  const canonicalFraction = millisStr ? `.${millisStr}` : "";
  const canonicalOffset = tzToken === "Z" ? "Z" : `${tzSign}${tzHoursStr}:${tzMinutesStr}`;
  const canonical = `${pad(year, 4)}-${pad(month, 2)}-${pad(day, 2)}T${pad(hour, 2)}:${pad(minute, 2)}:${pad(second, 2)}${canonicalFraction}${canonicalOffset}`;
  if (canonical !== value) {
    return { success: false, message: `Datetime must be canonical ISO-8601 (expected ${canonical})` };
  }
  return { success: true, value: new Date(epochMs) };
}

const isoDateStringToDate = z.string().superRefine((value, ctx) => {
  const parsed = parseStrictIsoDate(value);
  if (!parsed.success) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, message: parsed.message });
  }
}).transform((value) => {
  const parsed = parseStrictIsoDate(value);
  return parsed.success ? parsed.value : undefined;
}).nullable().optional();

const isoDateTimeStringToDate = z.string().superRefine((value, ctx) => {
  const parsed = parseStrictIsoDateTime(value);
  if (!parsed.success) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, message: parsed.message });
  }
}).transform((value) => {
  const parsed = parseStrictIsoDateTime(value);
  return parsed.success ? parsed.value : new Date();
});

const updateSettingsSchema = z.object({
  turnaroundDays: z.number().int().min(1).max(30).optional(),
  workdays: z.string().regex(/^[\d,\s]*$/).optional(),
  holidays: z.string().optional(),
  exclusionKeywords: z.string().optional(),
  cancelKeywords: z.string().optional(),
  deadlineDate: isoDateStringToDate,
  dateRangeStart: isoDateStringToDate,
  dateRangeEnd: isoDateStringToDate,
  capacityPerDay: z.number().int().min(1).max(50).nullable().optional(),
  selectedCalendarId: z.string().nullable().optional(),
  selectedCalendarIds: z.string().optional(),
});

const createOverrideSchema = z.object({
  eventId: z.string().min(1),
  eventStartTime: isoDateTimeStringToDate,
  linkSent: z.boolean().optional(),
  delivered: z.boolean().optional(),
  notes: z.string().optional(),
});

const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

declare module "express-session" {
  interface SessionData {
    userId: string;
    username: string;
  }
}

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.session?.userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  next();
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.post("/api/auth/init", async (req, res) => {
    try {
      const existingUser = await storage.getUserByUsername("Evans");
      if (existingUser) {
        res.json({ message: "User already exists", username: "Evans" });
        return;
      }
      
      const hashedPassword = await bcrypt.hash("123456", 10);
      const user = await storage.createUser({
        username: "Evans",
        password: hashedPassword,
      });
      
      res.json({ success: true, username: user.username });
    } catch (error: any) {
      console.error("Init user error:", error.message);
      res.status(500).json({ error: "Failed to initialize user" });
    }
  });

  app.get("/api/auth/session", async (req, res) => {
    if (req.session?.userId) {
      const user = await storage.getUserById(req.session.userId);
      if (user) {
        res.json({ authenticated: true, user: { id: user.id, username: user.username } });
        return;
      }
    }
    res.json({ authenticated: false });
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const validationResult = loginSchema.safeParse(req.body);
      if (!validationResult.success) {
        res.status(400).json({ error: "Invalid credentials format", details: validationResult.error.flatten() });
        return;
      }

      const { username, password } = validationResult.data;
      
      const user = await storage.getUserByUsername(username);
      if (!user) {
        res.status(401).json({ error: "Invalid username or password" });
        return;
      }

      const passwordMatch = await bcrypt.compare(password, user.password);
      if (!passwordMatch) {
        res.status(401).json({ error: "Invalid username or password" });
        return;
      }

      req.session.regenerate((err: Error | null) => {
        if (err) {
          console.error("Session regeneration error:", err.message);
          res.status(500).json({ error: "Login failed" });
          return;
        }
        
        req.session.userId = user.id;
        req.session.username = user.username;
        
        req.session.save((saveErr: Error | null) => {
          if (saveErr) {
            console.error("Session save error:", saveErr.message);
            res.status(500).json({ error: "Login failed" });
            return;
          }
          res.json({ success: true, user: { id: user.id, username: user.username } });
        });
      });
    } catch (error: any) {
      console.error("Login error:", error.message);
      res.status(500).json({ error: "Login failed" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err: Error | null) => {
      if (err) {
        res.status(500).json({ error: "Logout failed" });
        return;
      }
      res.json({ success: true });
    });
  });
  
  app.get("/api/calendars", requireAuth, async (req, res) => {
    try {
      const calendars = await listCalendars();
      res.json(calendars);
    } catch (error: any) {
      console.error("Error listing calendars:", error.message);
      if (error.message?.includes("not connected")) {
        res.json([]);
      } else {
        res.status(500).json({ error: "Failed to list calendars" });
      }
    }
  });

  app.get("/api/settings", requireAuth, async (req, res) => {
    try {
      let settings = await storage.getSettings();
      
      if (!settings) {
        settings = await storage.createSettings({
          turnaroundDays: 5,
          workdays: "1,2,3,4,5",
          holidays: "",
          exclusionKeywords: "FULL DAY,BLOCK,HOLD,OUT OF OFFICE",
          cancelKeywords: "CANCEL,CANCELLED,DID NOT COME,NO SHOW,NOT COMING",
        });
      }
      
      res.json(settings);
    } catch (error: any) {
      console.error("Error getting settings:", error.message);
      res.status(500).json({ error: "Failed to get settings" });
    }
  });

  app.patch("/api/settings", requireAuth, async (req, res) => {
    try {
      const validationResult = updateSettingsSchema.safeParse(req.body);
      if (!validationResult.success) {
        res.status(400).json({ error: "Invalid settings data", details: validationResult.error.flatten() });
        return;
      }
      
      const { deadlineDate, dateRangeStart, dateRangeEnd, ...restData } = validationResult.data;
      const settingsToUpdate: Record<string, any> = { ...restData };
      if (deadlineDate !== undefined) {
        settingsToUpdate.deadlineDate = deadlineDate ? deadlineDate.toISOString().split('T')[0] : null;
      }
      if (dateRangeStart !== undefined) {
        settingsToUpdate.dateRangeStart = dateRangeStart ? dateRangeStart.toISOString().split('T')[0] : null;
      }
      if (dateRangeEnd !== undefined) {
        settingsToUpdate.dateRangeEnd = dateRangeEnd ? dateRangeEnd.toISOString().split('T')[0] : null;
      }
      
      const settings = await storage.updateSettings(settingsToUpdate);
      res.json(settings);
    } catch (error: any) {
      console.error("Error updating settings:", error.message);
      res.status(500).json({ error: "Failed to update settings" });
    }
  });

  app.get("/api/events", requireAuth, async (req, res) => {
    try {
      const { calendarId, calendarIds, start, end, turnaroundDays } = req.query;
      
      const calendarIdList: string[] = [];
      if (calendarIds && typeof calendarIds === 'string' && calendarIds.length > 0) {
        calendarIdList.push(...calendarIds.split(',').filter(id => id.trim()));
      } else if (calendarId && typeof calendarId === 'string') {
        calendarIdList.push(calendarId);
      }
      
      if (calendarIdList.length === 0 || !start || !end) {
        res.json([]);
        return;
      }
      
      const settings = await storage.getSettings();
      const overrides = await storage.getAllOverrides();
      
      const overridesMap = new Map<string, { linkSent: boolean; linkSentAt: Date | null; delivered: boolean; notes: string; deliveredAt: Date | null }>();
      for (const o of overrides) {
        const key = `${o.eventId}|${o.eventStartTime.toISOString()}`;
        overridesMap.set(key, { linkSent: o.linkSent, linkSentAt: o.linkSentAt, delivered: o.delivered, notes: o.notes || '', deliveredAt: o.deliveredAt });
      }
      
      const allRawEvents: any[] = [];
      for (const calId of calendarIdList) {
        try {
          const rawEvents = await getEvents(calId, start as string, end as string);
          allRawEvents.push(...rawEvents.map(e => ({ ...e, calendarId: calId })));
        } catch (error: any) {
          console.error(`Error fetching from calendar ${calId}:`, error.message);
        }
      }
      
      const settingsConfig: Settings = {
        turnaroundDays: parseInt(turnaroundDays as string) || settings?.turnaroundDays || 5,
        workdays: parseWorkdays(settings?.workdays || "1,2,3,4,5"),
        holidays: parseHolidays(settings?.holidays || ""),
        exclusionKeywords: parseKeywords(settings?.exclusionKeywords || "FULL DAY,BLOCK,HOLD,OUT OF OFFICE"),
        cancelKeywords: parseKeywords(settings?.cancelKeywords || "CANCEL,CANCELLED,DID NOT COME,NO SHOW,NOT COMING"),
      };
      
      const events = processEvents(allRawEvents, settingsConfig, overridesMap);
      
      res.json(events);
    } catch (error: any) {
      console.error("Error fetching events:", error.message);
      res.status(500).json({ error: "Failed to fetch events" });
    }
  });

  app.get("/api/kpi", requireAuth, async (req, res) => {
    try {
      const { calendarId, calendarIds, start, end, turnaroundDays, deadline } = req.query;
      
      const calendarIdList: string[] = [];
      if (calendarIds && typeof calendarIds === 'string' && calendarIds.length > 0) {
        calendarIdList.push(...calendarIds.split(',').filter(id => id.trim()));
      } else if (calendarId && typeof calendarId === 'string') {
        calendarIdList.push(calendarId);
      }
      
      if (calendarIdList.length === 0 || !start || !end) {
        res.json({
          total: 0,
          done: 0,
          upcoming: 0,
          delivered: 0,
          dueThisWeek: 0,
          overdue: 0,
          dueByDeadline: 0,
          atRisk: 0,
        });
        return;
      }
      
      const settings = await storage.getSettings();
      const overrides = await storage.getAllOverrides();
      
      const overridesMap = new Map<string, { linkSent: boolean; linkSentAt: Date | null; delivered: boolean; notes: string; deliveredAt: Date | null }>();
      for (const o of overrides) {
        const key = `${o.eventId}|${o.eventStartTime.toISOString()}`;
        overridesMap.set(key, { linkSent: o.linkSent, linkSentAt: o.linkSentAt, delivered: o.delivered, notes: o.notes || '', deliveredAt: o.deliveredAt });
      }
      
      const allRawEvents: any[] = [];
      for (const calId of calendarIdList) {
        try {
          const rawEvents = await getEvents(calId, start as string, end as string);
          allRawEvents.push(...rawEvents.map(e => ({ ...e, calendarId: calId })));
        } catch (error: any) {
          console.error(`Error fetching from calendar ${calId}:`, error.message);
        }
      }
      
      const settingsConfig: Settings = {
        turnaroundDays: parseInt(turnaroundDays as string) || settings?.turnaroundDays || 5,
        workdays: parseWorkdays(settings?.workdays || "1,2,3,4,5"),
        holidays: parseHolidays(settings?.holidays || ""),
        exclusionKeywords: parseKeywords(settings?.exclusionKeywords || "FULL DAY,BLOCK,HOLD,OUT OF OFFICE"),
        cancelKeywords: parseKeywords(settings?.cancelKeywords || "CANCEL,CANCELLED,DID NOT COME,NO SHOW,NOT COMING"),
      };
      
      const events = processEvents(allRawEvents, settingsConfig, overridesMap);
      const kpis = calculateKPIs(events, deadline as string || null);
      
      res.json(kpis);
    } catch (error: any) {
      console.error("Error calculating KPIs:", error.message);
      res.status(500).json({ error: "Failed to calculate KPIs" });
    }
  });

  app.get("/api/forecast", requireAuth, async (req, res) => {
    try {
      const { calendarId, calendarIds, start, end, turnaroundDays, deadline, capacity } = req.query;
      
      const calendarIdList: string[] = [];
      if (calendarIds && typeof calendarIds === 'string' && calendarIds.length > 0) {
        calendarIdList.push(...calendarIds.split(',').filter(id => id.trim()));
      } else if (calendarId && typeof calendarId === 'string') {
        calendarIdList.push(calendarId);
      }
      
      if (calendarIdList.length === 0 || !start || !end || !deadline) {
        res.status(400).json({ error: "Missing required parameters" });
        return;
      }
      
      const settings = await storage.getSettings();
      const overrides = await storage.getAllOverrides();
      
      const overridesMap = new Map<string, { linkSent: boolean; linkSentAt: Date | null; delivered: boolean; notes: string; deliveredAt: Date | null }>();
      for (const o of overrides) {
        const key = `${o.eventId}|${o.eventStartTime.toISOString()}`;
        overridesMap.set(key, { linkSent: o.linkSent, linkSentAt: o.linkSentAt, delivered: o.delivered, notes: o.notes || '', deliveredAt: o.deliveredAt });
      }
      
      const allRawEvents: any[] = [];
      for (const calId of calendarIdList) {
        try {
          const rawEvents = await getEvents(calId, start as string, end as string);
          allRawEvents.push(...rawEvents.map(e => ({ ...e, calendarId: calId })));
        } catch (error: any) {
          console.error(`Error fetching from calendar ${calId}:`, error.message);
        }
      }
      
      const workdays = parseWorkdays(settings?.workdays || "1,2,3,4,5");
      const holidays = parseHolidays(settings?.holidays || "");
      
      const settingsConfig: Settings = {
        turnaroundDays: parseInt(turnaroundDays as string) || settings?.turnaroundDays || 5,
        workdays,
        holidays,
        exclusionKeywords: parseKeywords(settings?.exclusionKeywords || "FULL DAY,BLOCK,HOLD,OUT OF OFFICE"),
        cancelKeywords: parseKeywords(settings?.cancelKeywords || "CANCEL,CANCELLED,DID NOT COME,NO SHOW,NOT COMING"),
      };
      
      const events = processEvents(allRawEvents, settingsConfig, overridesMap);
      
      const capacityPerDay = capacity ? parseInt(capacity as string) : null;
      const forecast = calculateForecast(
        events,
        deadline as string,
        workdays,
        holidays,
        capacityPerDay
      );
      
      res.json(forecast);
    } catch (error: any) {
      console.error("Error calculating forecast:", error.message);
      res.status(500).json({ error: "Failed to calculate forecast" });
    }
  });

  app.get("/api/analytics", requireAuth, async (req, res) => {
    try {
      const { calendarId, calendarIds, start, end, turnaroundDays } = req.query;
      
      const calendarIdList: string[] = [];
      if (calendarIds && typeof calendarIds === 'string' && calendarIds.length > 0) {
        calendarIdList.push(...calendarIds.split(',').filter(id => id.trim()));
      } else if (calendarId && typeof calendarId === 'string') {
        calendarIdList.push(calendarId);
      }
      
      if (calendarIdList.length === 0 || !start || !end) {
        res.json({
          monthlyStats: [],
          overallCompletionRate: 0,
          overallOnTimeRate: 0,
          avgTurnaroundDays: 0,
          totalProjects: 0,
          deliveredProjects: 0,
        });
        return;
      }
      
      const settings = await storage.getSettings();
      const overrides = await storage.getAllOverrides();
      
      const overridesMap = new Map<string, { linkSent: boolean; linkSentAt: Date | null; delivered: boolean; notes: string; deliveredAt: Date | null }>();
      for (const o of overrides) {
        const key = `${o.eventId}|${o.eventStartTime.toISOString()}`;
        overridesMap.set(key, { linkSent: o.linkSent, linkSentAt: o.linkSentAt, delivered: o.delivered, notes: o.notes || '', deliveredAt: o.deliveredAt });
      }
      
      const allRawEvents: any[] = [];
      for (const calId of calendarIdList) {
        try {
          const rawEvents = await getEvents(calId, start as string, end as string);
          allRawEvents.push(...rawEvents.map(e => ({ ...e, calendarId: calId })));
        } catch (error: any) {
          console.error(`Error fetching from calendar ${calId}:`, error.message);
        }
      }
      
      const settingsConfig: Settings = {
        turnaroundDays: parseInt(turnaroundDays as string) || settings?.turnaroundDays || 5,
        workdays: parseWorkdays(settings?.workdays || "1,2,3,4,5"),
        holidays: parseHolidays(settings?.holidays || ""),
        exclusionKeywords: parseKeywords(settings?.exclusionKeywords || "FULL DAY,BLOCK,HOLD,OUT OF OFFICE"),
        cancelKeywords: parseKeywords(settings?.cancelKeywords || "CANCEL,CANCELLED,DID NOT COME,NO SHOW,NOT COMING"),
      };
      
      const events = processEvents(allRawEvents, settingsConfig, overridesMap);
      const analytics = calculateAnalytics(events, settingsConfig);
      
      res.json(analytics);
    } catch (error: any) {
      console.error("Error calculating analytics:", error.message);
      res.status(500).json({ error: "Failed to calculate analytics" });
    }
  });

  app.post("/api/overrides", requireAuth, async (req, res) => {
    try {
      const validationResult = createOverrideSchema.safeParse(req.body);
      if (!validationResult.success) {
        res.status(400).json({ error: "Invalid override data", details: validationResult.error.flatten() });
        return;
      }
      
      const { eventId, eventStartTime, linkSent, delivered, notes } = validationResult.data;
      
      const override = await storage.upsertOverride({
        eventId,
        eventStartTime: new Date(eventStartTime),
        linkSent,
        delivered,
        notes,
      });
      
      res.json(override);
    } catch (error: any) {
      console.error("Error saving override:", error.message);
      res.status(500).json({ error: "Failed to save override" });
    }
  });

  const bulkOverrideItemSchema = z.object({
    eventId: z.string().min(1),
    eventStartTime: z.string().min(1),
  });

  const bulkOverrideSchema = z.object({
    events: z.array(bulkOverrideItemSchema).min(1, "At least one event is required"),
    action: z.enum(["markLinkSent", "markLinkNotSent", "markDelivered", "markNotDelivered", "setNotes"]),
    notes: z.string().optional(),
  });

  app.post("/api/overrides/bulk", requireAuth, async (req, res) => {
    try {
      const validationResult = bulkOverrideSchema.safeParse(req.body);
      if (!validationResult.success) {
        res.status(400).json({ 
          error: "Invalid bulk override data", 
          details: validationResult.error.flatten() 
        });
        return;
      }
      
      const { events, action, notes } = validationResult.data;
      
      const results = [];
      const errors: { eventId: string; eventStartTime: string; error: string }[] = [];
      
      for (const event of events) {
        const { eventId, eventStartTime } = event;
        
        const parsedDate = new Date(eventStartTime);
        if (isNaN(parsedDate.getTime())) {
          errors.push({ eventId, eventStartTime, error: "Invalid date format" });
          continue;
        }
        
        const overrideData: {
          eventId: string;
          eventStartTime: Date;
          linkSent?: boolean;
          delivered?: boolean;
          notes?: string;
        } = {
          eventId,
          eventStartTime: parsedDate,
        };
        
        if (action === "markLinkSent") {
          overrideData.linkSent = true;
        } else if (action === "markLinkNotSent") {
          overrideData.linkSent = false;
        } else if (action === "markDelivered") {
          overrideData.delivered = true;
        } else if (action === "markNotDelivered") {
          overrideData.delivered = false;
        } else if (action === "setNotes") {
          overrideData.notes = notes || "";
        }
        
        try {
          const override = await storage.upsertOverride(overrideData);
          results.push(override);
        } catch (itemError: any) {
          errors.push({ eventId, eventStartTime, error: itemError.message });
        }
      }
      
      res.json({ 
        updated: results.length, 
        failed: errors.length,
        results,
        errors: errors.length > 0 ? errors : undefined
      });
    } catch (error: any) {
      console.error("Error bulk updating overrides:", error.message);
      res.status(500).json({ error: "Failed to bulk update overrides" });
    }
  });

  return httpServer;
}
