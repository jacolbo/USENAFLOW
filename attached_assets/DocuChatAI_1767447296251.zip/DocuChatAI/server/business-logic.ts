import { parseISO, addDays, isAfter, isBefore, startOfDay, getDay, format, isWeekend, differenceInDays, startOfWeek, endOfWeek, isWithinInterval } from 'date-fns';
import { toZonedTime, fromZonedTime } from 'date-fns-tz';

const TIMEZONE = 'Africa/Johannesburg';

export interface RawEvent {
  id: string;
  title: string;
  startTime: string;
  endTime: string;
  description: string;
}

export interface ClassifiedEvent {
  id: string;
  title: string;
  startTime: string;
  endTime: string;
  status: 'done' | 'upcoming' | 'excluded';
  deliveryDueDate: string | null;
  isLinkSent: boolean;
  linkSentAt: string | null;
  isDelivered: boolean;
  isOverdue: boolean;
  deliveredAt: string | null;
  notes: string;
}

export interface Settings {
  turnaroundDays: number;
  workdays: number[];
  holidays: string[];
  exclusionKeywords: string[];
  cancelKeywords: string[];
}

export function parseWorkdays(workdaysStr: string): number[] {
  if (!workdaysStr) return [1, 2, 3, 4, 5];
  return workdaysStr.split(',').map(d => parseInt(d.trim())).filter(d => !isNaN(d));
}

export function parseHolidays(holidaysStr: string | null): string[] {
  if (!holidaysStr) return [];
  return holidaysStr.split('\n').map(h => h.trim()).filter(h => h.match(/^\d{4}-\d{2}-\d{2}$/));
}

export function parseKeywords(keywordsStr: string): string[] {
  if (!keywordsStr) return [];
  return keywordsStr.split(',').map(k => k.trim().toUpperCase()).filter(k => k.length > 0);
}

export function isWorkday(date: Date, workdays: number[], holidays: string[]): boolean {
  const dayOfWeek = getDay(date);
  if (!workdays.includes(dayOfWeek)) return false;
  
  const dateStr = format(date, 'yyyy-MM-dd');
  if (holidays.includes(dateStr)) return false;
  
  return true;
}

export function addWorkingDays(
  startDate: Date,
  days: number,
  workdays: number[],
  holidays: string[]
): Date {
  let result = startOfDay(startDate);
  let addedDays = 0;
  
  while (addedDays < days) {
    result = addDays(result, 1);
    if (isWorkday(result, workdays, holidays)) {
      addedDays++;
    }
  }
  
  return result;
}

export function countWorkingDays(
  startDate: Date,
  endDate: Date,
  workdays: number[],
  holidays: string[]
): number {
  let count = 0;
  let current = startOfDay(startDate);
  const end = startOfDay(endDate);
  
  while (isBefore(current, end) || format(current, 'yyyy-MM-dd') === format(end, 'yyyy-MM-dd')) {
    if (isWorkday(current, workdays, holidays)) {
      count++;
    }
    current = addDays(current, 1);
    if (isAfter(current, end)) break;
  }
  
  return count;
}

export function classifyEvent(
  event: RawEvent,
  settings: Settings,
  now: Date = new Date()
): 'done' | 'upcoming' | 'excluded' {
  const title = event.title.toUpperCase();
  
  for (const keyword of settings.exclusionKeywords) {
    if (title.includes(keyword)) {
      return 'excluded';
    }
  }
  
  for (const keyword of settings.cancelKeywords) {
    if (title.includes(keyword)) {
      return 'excluded';
    }
  }
  
  const endTime = parseISO(event.endTime);
  const nowInTz = toZonedTime(now, TIMEZONE);
  const endInTz = toZonedTime(endTime, TIMEZONE);
  
  if (isBefore(endInTz, nowInTz)) {
    return 'done';
  }
  
  return 'upcoming';
}

export function calculateDeliveryDueDate(
  shootDate: Date,
  turnaroundDays: number,
  workdays: number[],
  holidays: string[]
): Date {
  return addWorkingDays(shootDate, turnaroundDays, workdays, holidays);
}

export function isOverdue(
  deliveryDueDate: Date,
  isDelivered: boolean,
  now: Date = new Date()
): boolean {
  if (isDelivered) return false;
  
  const nowInTz = toZonedTime(now, TIMEZONE);
  const dueInTz = toZonedTime(deliveryDueDate, TIMEZONE);
  
  return isAfter(startOfDay(nowInTz), startOfDay(dueInTz));
}

export function processEvents(
  rawEvents: RawEvent[],
  settings: Settings,
  overrides: Map<string, { linkSent: boolean; linkSentAt: Date | null; delivered: boolean; notes: string; deliveredAt: Date | null }>,
  now: Date = new Date()
): ClassifiedEvent[] {
  const processed: ClassifiedEvent[] = [];
  
  for (const event of rawEvents) {
    const status = classifyEvent(event, settings, now);
    
    if (status === 'excluded') continue;
    
    const shootDate = parseISO(event.startTime);
    const deliveryDueDate = calculateDeliveryDueDate(
      shootDate,
      settings.turnaroundDays,
      settings.workdays,
      settings.holidays
    );
    
    const overrideKey = `${event.id}|${new Date(event.startTime).toISOString()}`;
    const override = overrides.get(overrideKey);
    const isLinkSent = override?.linkSent ?? false;
    const linkSentAt = override?.linkSentAt ?? null;
    const isDelivered = override?.delivered ?? false;
    const notes = override?.notes ?? '';
    const deliveredAt = override?.deliveredAt ?? null;
    
    // Overdue is based solely on due date and manual delivery status
    // A project is overdue if: past due date AND not manually marked as delivered
    const isOverdueStatus = isOverdue(deliveryDueDate, isDelivered, now);
    
    processed.push({
      id: event.id,
      title: event.title,
      startTime: event.startTime,
      endTime: event.endTime,
      status,
      deliveryDueDate: format(deliveryDueDate, 'yyyy-MM-dd'),
      isLinkSent,
      linkSentAt: linkSentAt ? linkSentAt.toISOString() : null,
      isDelivered,
      isOverdue: isOverdueStatus,
      deliveredAt: deliveredAt ? deliveredAt.toISOString() : null,
      notes,
    });
  }
  
  return processed;
}

export function calculateKPIs(
  events: ClassifiedEvent[],
  deadlineDate: string | null,
  now: Date = new Date()
): {
  total: number;
  done: number;
  upcoming: number;
  delivered: number;
  dueThisWeek: number;
  overdue: number;
  dueByDeadline: number;
  atRisk: number;
} {
  const nowInTz = toZonedTime(now, TIMEZONE);
  const weekStart = startOfWeek(nowInTz, { weekStartsOn: 1 });
  const weekEnd = endOfWeek(nowInTz, { weekStartsOn: 1 });
  
  let total = 0;
  let done = 0;
  let upcoming = 0;
  let delivered = 0;
  let dueThisWeek = 0;
  let overdue = 0;
  let dueByDeadline = 0;
  let atRisk = 0;
  
  for (const event of events) {
    total++;
    
    if (event.status === 'done') {
      done++;
      if (event.isDelivered) {
        delivered++;
      }
    } else {
      upcoming++;
    }
    
    if (event.deliveryDueDate) {
      const dueDate = parseISO(event.deliveryDueDate);
      
      if (isWithinInterval(dueDate, { start: weekStart, end: weekEnd })) {
        dueThisWeek++;
      }
      
      if (event.isOverdue) {
        overdue++;
      }
      
      if (deadlineDate) {
        const deadline = parseISO(deadlineDate);
        if (isBefore(dueDate, deadline) || format(dueDate, 'yyyy-MM-dd') === deadlineDate) {
          dueByDeadline++;
        } else {
          atRisk++;
        }
      }
    }
  }
  
  return {
    total,
    done,
    upcoming,
    delivered,
    dueThisWeek,
    overdue,
    dueByDeadline,
    atRisk,
  };
}

export function calculateForecast(
  events: ClassifiedEvent[],
  deadlineDate: string,
  workdays: number[],
  holidays: string[],
  capacityPerDay: number | null,
  now: Date = new Date()
): {
  totalProjects: number;
  projectsDueByDeadline: number;
  projectsAtRisk: number;
  requiredThroughput: number;
  remainingWorkingDays: number;
  feasibilityStatus: 'green' | 'amber' | 'red';
  dailyWorkload: Array<{
    date: string;
    count: number;
    isWorkday: boolean;
    isHoliday: boolean;
  }>;
} {
  const deadline = parseISO(deadlineDate);
  const nowInTz = toZonedTime(now, TIMEZONE);
  const todayStr = format(nowInTz, 'yyyy-MM-dd');
  
  const undeliveredEvents = events.filter(e => !e.isDelivered);
  
  const projectsDueByDeadline = undeliveredEvents.filter(e => {
    if (!e.deliveryDueDate) return false;
    return isBefore(parseISO(e.deliveryDueDate), deadline) || e.deliveryDueDate === deadlineDate;
  }).length;
  
  const projectsAtRisk = undeliveredEvents.filter(e => {
    if (!e.deliveryDueDate) return false;
    return isAfter(parseISO(e.deliveryDueDate), deadline);
  }).length;
  
  const remainingWorkingDays = countWorkingDays(
    parseISO(todayStr),
    deadline,
    workdays,
    holidays
  );
  
  const requiredThroughput = remainingWorkingDays > 0 
    ? projectsDueByDeadline / remainingWorkingDays 
    : projectsDueByDeadline;
  
  let feasibilityStatus: 'green' | 'amber' | 'red' = 'green';
  
  if (capacityPerDay !== null) {
    if (requiredThroughput > capacityPerDay) {
      feasibilityStatus = 'red';
    } else if (requiredThroughput > capacityPerDay * 0.8) {
      feasibilityStatus = 'amber';
    }
  } else {
    if (requiredThroughput > 5) {
      feasibilityStatus = 'red';
    } else if (requiredThroughput > 3) {
      feasibilityStatus = 'amber';
    }
  }
  
  const dailyWorkload: Array<{
    date: string;
    count: number;
    isWorkday: boolean;
    isHoliday: boolean;
  }> = [];
  
  const dueDateCounts = new Map<string, number>();
  for (const event of undeliveredEvents) {
    if (event.deliveryDueDate) {
      const current = dueDateCounts.get(event.deliveryDueDate) || 0;
      dueDateCounts.set(event.deliveryDueDate, current + 1);
    }
  }
  
  let currentDate = parseISO(todayStr);
  while (isBefore(currentDate, deadline) || format(currentDate, 'yyyy-MM-dd') === deadlineDate) {
    const dateStr = format(currentDate, 'yyyy-MM-dd');
    const dayOfWeek = getDay(currentDate);
    const isHoliday = holidays.includes(dateStr);
    const isWorkdayFlag = workdays.includes(dayOfWeek) && !isHoliday;
    
    dailyWorkload.push({
      date: dateStr,
      count: dueDateCounts.get(dateStr) || 0,
      isWorkday: isWorkdayFlag,
      isHoliday,
    });
    
    currentDate = addDays(currentDate, 1);
  }
  
  return {
    totalProjects: undeliveredEvents.length,
    projectsDueByDeadline,
    projectsAtRisk,
    requiredThroughput,
    remainingWorkingDays,
    feasibilityStatus,
    dailyWorkload,
  };
}

export interface MonthlyStats {
  month: string;
  done: number;
  delivered: number;
  onTimeDeliveries: number;
  avgTurnaroundDays: number;
}

export interface AnalyticsData {
  monthlyStats: MonthlyStats[];
  overallCompletionRate: number;
  overallOnTimeRate: number;
  avgTurnaroundDays: number;
  totalProjects: number;
  deliveredProjects: number;
}

export function calculateAnalytics(
  events: ClassifiedEvent[],
  settings: Settings,
  now: Date = new Date()
): AnalyticsData {
  const doneEvents = events.filter(e => e.status === 'done');
  const deliveredEvents = doneEvents.filter(e => e.isDelivered);
  
  const monthlyMap = new Map<string, {
    done: number;
    delivered: number;
    onTimeDeliveries: number;
    turnaroundDays: number[];
  }>();
  
  for (const event of doneEvents) {
    const shootDate = parseISO(event.startTime);
    const monthKey = format(shootDate, 'yyyy-MM');
    
    if (!monthlyMap.has(monthKey)) {
      monthlyMap.set(monthKey, {
        done: 0,
        delivered: 0,
        onTimeDeliveries: 0,
        turnaroundDays: [],
      });
    }
    
    const stats = monthlyMap.get(monthKey)!;
    stats.done++;
    
    if (event.isDelivered && event.deliveredAt && event.deliveryDueDate) {
      stats.delivered++;
      
      const deliveredDate = parseISO(event.deliveredAt);
      const dueDate = parseISO(event.deliveryDueDate);
      
      const deliveredDateInTz = startOfDay(toZonedTime(deliveredDate, TIMEZONE));
      const dueDateInTz = startOfDay(toZonedTime(dueDate, TIMEZONE));
      
      if (!isAfter(deliveredDateInTz, dueDateInTz)) {
        stats.onTimeDeliveries++;
      }
      
      const turnaround = countWorkingDays(
        shootDate,
        deliveredDateInTz,
        settings.workdays,
        settings.holidays
      );
      stats.turnaroundDays.push(turnaround);
    } else if (event.isDelivered) {
      stats.delivered++;
    }
  }
  
  const monthlyStats: MonthlyStats[] = [];
  const sortedMonths = Array.from(monthlyMap.keys()).sort();
  
  for (const month of sortedMonths) {
    const stats = monthlyMap.get(month)!;
    const avgTurnaround = stats.turnaroundDays.length > 0
      ? stats.turnaroundDays.reduce((a, b) => a + b, 0) / stats.turnaroundDays.length
      : 0;
    
    monthlyStats.push({
      month,
      done: stats.done,
      delivered: stats.delivered,
      onTimeDeliveries: stats.onTimeDeliveries,
      avgTurnaroundDays: Math.round(avgTurnaround * 10) / 10,
    });
  }
  
  const allTurnaroundDays: number[] = [];
  monthlyMap.forEach((stats) => {
    allTurnaroundDays.push(...stats.turnaroundDays);
  });
  
  const totalDone = doneEvents.length;
  const totalDelivered = deliveredEvents.length;
  const onTimeCount = monthlyStats.reduce((sum, m) => sum + m.onTimeDeliveries, 0);
  
  return {
    monthlyStats,
    overallCompletionRate: totalDone > 0 ? (totalDelivered / totalDone) * 100 : 0,
    overallOnTimeRate: totalDelivered > 0 ? (onTimeCount / totalDelivered) * 100 : 0,
    avgTurnaroundDays: allTurnaroundDays.length > 0
      ? Math.round((allTurnaroundDays.reduce((a, b) => a + b, 0) / allTurnaroundDays.length) * 10) / 10
      : 0,
    totalProjects: totalDone,
    deliveredProjects: totalDelivered,
  };
}
