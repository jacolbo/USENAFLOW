import { userSettings, eventOverrides, users, type UserSettings, type InsertUserSettings, type EventOverride, type InsertEventOverride, type User, type InsertUser } from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  getSettings(): Promise<UserSettings | undefined>;
  createSettings(settings: InsertUserSettings): Promise<UserSettings>;
  updateSettings(settings: Partial<InsertUserSettings>): Promise<UserSettings>;
  
  getOverride(eventId: string, eventStartTime: Date): Promise<EventOverride | undefined>;
  getAllOverrides(): Promise<EventOverride[]>;
  upsertOverride(override: InsertEventOverride): Promise<EventOverride>;

  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUserById(id: string): Promise<User | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getSettings(): Promise<UserSettings | undefined> {
    const [settings] = await db.select().from(userSettings).limit(1);
    return settings || undefined;
  }

  async createSettings(settings: InsertUserSettings): Promise<UserSettings> {
    const [created] = await db
      .insert(userSettings)
      .values(settings)
      .returning();
    return created;
  }

  async updateSettings(settings: Partial<InsertUserSettings>): Promise<UserSettings> {
    const existing = await this.getSettings();
    
    if (!existing) {
      return this.createSettings(settings as InsertUserSettings);
    }
    
    const [updated] = await db
      .update(userSettings)
      .set({ ...settings, updatedAt: new Date() })
      .where(eq(userSettings.id, existing.id))
      .returning();
    
    return updated;
  }

  async getOverride(eventId: string, eventStartTime: Date): Promise<EventOverride | undefined> {
    const [override] = await db
      .select()
      .from(eventOverrides)
      .where(
        and(
          eq(eventOverrides.eventId, eventId),
          eq(eventOverrides.eventStartTime, eventStartTime)
        )
      );
    return override || undefined;
  }

  async getAllOverrides(): Promise<EventOverride[]> {
    return db.select().from(eventOverrides);
  }

  async upsertOverride(override: InsertEventOverride): Promise<EventOverride> {
    const existing = await this.getOverride(override.eventId, new Date(override.eventStartTime));
    
    if (existing) {
      const updateData: Partial<EventOverride> = { updatedAt: new Date() };
      if (override.linkSent !== undefined) {
        updateData.linkSent = override.linkSent;
        if (override.linkSent && !existing.linkSentAt) {
          updateData.linkSentAt = new Date();
        } else if (!override.linkSent) {
          updateData.linkSentAt = null;
        }
      }
      if (override.delivered !== undefined) {
        updateData.delivered = override.delivered;
        if (override.delivered && !existing.deliveredAt) {
          updateData.deliveredAt = new Date();
        } else if (!override.delivered) {
          updateData.deliveredAt = null;
        }
      }
      if (override.notes !== undefined) updateData.notes = override.notes;
      
      const [updated] = await db
        .update(eventOverrides)
        .set(updateData)
        .where(eq(eventOverrides.id, existing.id))
        .returning();
      return updated;
    }
    
    const [created] = await db
      .insert(eventOverrides)
      .values({
        ...override,
        linkSent: override.linkSent ?? false,
        linkSentAt: override.linkSent ? new Date() : null,
        delivered: override.delivered ?? false,
        deliveredAt: override.delivered ? new Date() : null,
        notes: override.notes ?? '',
      })
      .returning();
    return created;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [created] = await db
      .insert(users)
      .values(user)
      .returning();
    return created;
  }

  async getUserById(id: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.id, id));
    return user || undefined;
  }
}

export const storage = new DatabaseStorage();
